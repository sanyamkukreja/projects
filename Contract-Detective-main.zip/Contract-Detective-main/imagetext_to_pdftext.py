# import fitz  # PyMuPDF
# import pytesseract
# from PIL import Image
# import io

# def extract_images_from_pdf(pdf_path):
#     images = []
#     doc = fitz.open(pdf_path)
    
#     # Iterate through all pages
#     for page_number in range(len(doc)):
#         page = doc.load_page(page_number)
#         image_list = page.get_images(full=True)
        
#         # Collect all images in the page
#         for image_index, image_info in enumerate(image_list):
#             xref = image_info[0]
#             base_image = doc.extract_image(xref)
#             image_bytes = base_image["image"]
#             image = Image.open(io.BytesIO(image_bytes))
#             images.append((image, page_number))
    
#     return images

# def create_text_page(doc, text):
#     lines = text.split("\n")
#     max_line = max(lines, key=len)
#     max_line_width = len(max_line) * 6  # Estimate width based on average character width (adjust as needed)
#     text_height = len(lines) * 14  # Estimate height based on average line height (adjust as needed)

#     # Create a new page in the existing PDF document
#     page = doc.new_page(width=max_line_width, height=text_height)

#     # Insert text at the top-left corner of the page
#     page.insert_text((50, 50), text, fontsize=10)
    
#     return doc

# def extract_text_from_images_in_pdf(pdf_path, output_pdf_path):
#     images = extract_images_from_pdf(pdf_path)
    
#     # Initialize Tesseract OCR
#     pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\tessdata\tesseract.exe'
#     # pytesseract.pytesseract.tesseract_cmd = r'C:\Users\Atin\Downloads\tesseract-ocr-w64-setup-5.4.0.20240606.exe'

    
#     # Open the original PDF
#     original_doc = fitz.open(pdf_path)
    
#     # Create a new PDF document
#     new_doc = fitz.open()
    
#     image_pages = [page_number for _, page_number in images]
    
#     for page_num in range(len(original_doc)):
#         # If it's not a page with an image, just copy it to the new document
#         if page_num not in image_pages:
#             new_doc.insert_pdf(original_doc, from_page=page_num, to_page=page_num)
#         else:
#             # Find all images on the current page
#             for image, img_page_number in images:
#                 if img_page_number == page_num:
#                     # Perform OCR on the image
#                     image_text = pytesseract.image_to_string(image, lang='eng')
#                     # Create a new page with the OCR-extracted text
#                     new_doc = create_text_page(new_doc, image_text)
    
#     # Save the new PDF
#     new_doc.save(output_pdf_path)
#     return output_pdf_path

# # Example usage
# pdf_path = 'Test1.pdf'
# output_pdf_path = 'output_test.pdf'
# extract_text_from_images_in_pdf(pdf_path, output_pdf_path)


















# import fitz  # PyMuPDF
# import pytesseract
# from PIL import Image
# import io

# def extract_images_from_pdf(pdf_path):
#     images = []
#     doc = fitz.open(pdf_path)
    
#     # Iterate through all pages
#     for page_number in range(len(doc)):
#         page = doc.load_page(page_number)
#         image_list = page.get_images(full=True)
        
#         # Collect all images in the page
#         for image_index, image_info in enumerate(image_list):
#             xref = image_info[0]
#             base_image = doc.extract_image(xref)
#             image_bytes = base_image["image"]
#             image = Image.open(io.BytesIO(image_bytes))
#             images.append((image, page_number))
    
#     return images

# def create_text_page(doc, text):
#     lines = text.split("\n")
#     max_line = max(lines, key=len)
#     max_line_width = len(max_line) * 6  # Estimate width based on average character width (adjust as needed)
#     text_height = len(lines) * 18  # Estimate height based on average line height (adjust as needed)

#     # Create a new page in the existing PDF document
#     page = doc.new_page(width=max_line_width, height=text_height)

#     # Insert text at the top-left corner of the page
#     page.insert_text((50, 50), text, fontsize=12)
    
#     return doc

# def extract_text_from_images_in_pdf(pdf_path, output_pdf_path):
#     images = extract_images_from_pdf(pdf_path)
    
#     # Initialize Tesseract OCR
#     pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
    
#     # Open the original PDF
#     original_doc = fitz.open(pdf_path)
    
#     # Create a new PDF document
#     new_doc = fitz.open()
    
#     image_pages = [page_number for _, page_number in images]
    
#     for page_num in range(len(original_doc)):
#         # If it's not a page with an image, just copy it to the new document
#         if page_num not in image_pages:
#             new_doc.insert_pdf(original_doc, from_page=page_num, to_page=page_num)
#         else:
#             # Find all images on the current page
#             for image, img_page_number in images:
#                 if img_page_number == page_num:
#                     # Perform OCR on the image
#                     image_text = pytesseract.image_to_string(image, lang='eng')
                    
#                     # Print the extracted text to the terminal
#                     print(f"Extracted text from page {page_num}:\n{image_text}\n")
                    
#                     # Create a new page with the OCR-extracted text
#                     new_doc = create_text_page(new_doc, image_text)
    
#     # Save the new PDF
#     new_doc.save(output_pdf_path)
#     return output_pdf_path

# # Example usage
# pdf_path = 'Test1.pdf'
# output_pdf_path = 'output_test.pdf'
# extract_text_from_images_in_pdf(pdf_path, output_pdf_path)










# import fitz  # PyMuPDF
# import pytesseract
# from PIL import Image
# import io

# def extract_images_from_pdf(pdf_path):
#     images = []
#     doc = fitz.open(pdf_path)
    
#     # Iterate through all pages
#     for page_number in range(len(doc)):
#         page = doc.load_page(page_number)
#         image_list = page.get_images(full=True)
        
#         # Collect all images in the page
#         for image_index, image_info in enumerate(image_list):
#             xref = image_info[0]
#             base_image = doc.extract_image(xref)
#             image_bytes = base_image["image"]
#             image = Image.open(io.BytesIO(image_bytes))
#             images.append((image, page_number))
    
#     return images

# def has_text_on_page(page):
#     # Function to check if a PDF page has any visible text
#     text = page.get_text()
#     return bool(text.strip())

# def create_text_page(doc, text):
#     lines = text.split("\n")
#     max_line = max(lines, key=len)
#     max_line_width = len(max_line) * 6  # Estimate width based on average character width (adjust as needed)
#     text_height = len(lines) * 18  # Estimate height based on average line height (adjust as needed)

#     # Create a new page in the existing PDF document
#     page = doc.new_page(width=max_line_width, height=text_height)

#     # Insert text at the top-left corner of the page
#     page.insert_text((50, 50), text, fontsize=12)
    
#     return doc

# def extract_text_from_images_in_pdf(pdf_path, output_pdf_path):
#     images = extract_images_from_pdf(pdf_path)
    
#     # Initialize Tesseract OCR
#     pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
    
#     # Open the original PDF
#     original_doc = fitz.open(pdf_path)
    
#     # Create a new PDF document
#     new_doc = fitz.open()
    
#     image_pages = [page_number for _, page_number in images]
    
#     for page_num in range(len(original_doc)):
#         page = original_doc.load_page(page_num)
        
#         # Check if the page contains any visible text
#         if has_text_on_page(page):
#             # If there is text on the page, directly copy it to the new document
#             new_doc.insert_pdf(original_doc, from_page=page_num, to_page=page_num)
#         else:
#             # If there are images on the page, extract text from them
#             if page_num in image_pages:
#                 for image, img_page_number in images:
#                     if img_page_number == page_num:
#                         # Perform OCR on the image
#                         image_text = pytesseract.image_to_string(image, lang='eng')
                        
#                         # Print the extracted text to the terminal
#                         print(f"Extracted text from page {page_num}:\n{image_text}\n")
                        
#                         # Create a new page with the OCR-extracted text
#                         new_doc = create_text_page(new_doc, image_text)
#             else:
#                 # If neither text nor images (though this case may be rare), just copy the page
#                 new_doc.insert_pdf(original_doc, from_page=page_num, to_page=page_num)
    
#     # Save the new PDF
#     new_doc.save(output_pdf_path)
#     return output_pdf_path

# # Example usage
# pdf_path = 'Test2.pdf'
# output_pdf_path = 'output_test1.pdf'
# extract_text_from_images_in_pdf(pdf_path, output_pdf_path)
































# main code ...................................




import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import io
import os
import cv2
import numpy as np
from pytesseract import Output

def extract_images_from_pdf(pdf_path):
    images = []
    doc = fitz.open(pdf_path)
    
    for page_number in range(len(doc)):
        page = doc.load_page(page_number)
        image_list = page.get_images(full=True)
        
        for image_index, image_info in enumerate(image_list):
            xref = image_info[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image = Image.open(io.BytesIO(image_bytes))
            images.append((image, page_number))
    
    return images

def extract_text_with_formatting(image):
    gray = cv2.cvtColor(np.array(image), cv2.COLOR_BGR2GRAY)
    custom_config = r'--oem 3 --psm 4'
    text = pytesseract.image_to_string(gray,config=custom_config)
    return text



def create_text_page(doc, text):
    lines = text.split("\n")
    max_line = max(lines, key=len)
    max_line_width = len(max_line) * 5
    text_height = len(lines) * 10

    page = doc.new_page(width=max_line_width  , height=text_height + 100)
    text_position = 70
    for line in lines:
        page.insert_text((50, text_position), line, fontsize=10)
        text_position += 10
    
    return doc




def extract_text_from_images_in_pdf(pdf_path, output_pdf_path):
    images = extract_images_from_pdf(pdf_path)
    
    os.environ['TESSDATA_PREFIX'] = r'C:\Program Files (x86)\Tesseract-OCR\tessdata'
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
    
    original_doc = fitz.open(pdf_path)
    new_doc = fitz.open()
    
    image_pages = [page_number for _, page_number in images]
    
    for page_num in range(len(original_doc)):
        page = original_doc.load_page(page_num)
        text = page.get_text("text")
        
        if page_num not in image_pages:
            new_doc.insert_pdf(original_doc, from_page=page_num, to_page=page_num)
        else:
            for image, img_page_number in images:
                if img_page_number == page_num:
                    if not text.strip():  # Only convert to text if there is no text on the page
                        text = extract_text_with_formatting(image)
                        new_doc = create_text_page(new_doc, text)
                    else:
                        new_doc.insert_pdf(original_doc, from_page=page_num, to_page=page_num)
    
    new_doc.save(output_pdf_path)
    return output_pdf_path

# Example usage
pdf_path = 'Test1.pdf'
output_pdf_path = 'output_test.pdf'
extract_text_from_images_in_pdf(pdf_path, output_pdf_path)