import fitz
import json
import re
import os
from datetime import datetime
from utils import (
    text as main_page_text,
    found_reference,
    not_found_ref,
    parent_ul_tag,
    disclaimer,
)



import fitz  # PyMuPDF
from datetime import datetime

def footer_apply(document):
    width_mapping = {
        421: 180.5,   # If page width is 421, set footer_x to half of it
        297.5: 118.75,  # If page width is 297.5, set footer_x to half of it
    }
    current_date = datetime.now().strftime("%d/%m/%Y")
    
    for i in range(len(document)):
        page = document[i]
        footer_text = f"Page {i + 1} of {len(document)}"
        footer_sentence = f"This document was scanned by ContractDetective.com on {current_date}."
        footer_notice = "This is not an addendum or modification and requires human review."

        footer_height = 20 
        footer_width = page.rect.width  

        if footer_width in width_mapping:
            footer_x = width_mapping[footer_width] - 20 
        else:
            footer_x = footer_width / 2 - 20 

        footer_y = page.rect.height - footer_height - 15 
        footer_point = fitz.Point(footer_x, footer_y)
        page.insert_text(footer_point, footer_text, fontsize=10, color=(0, 0, 0))

        if footer_width in width_mapping:
            footer_x1 = width_mapping[footer_width] - 100 
        else:
            footer_x1 = footer_width / 2 - 150
        footer_y1 = page.rect.height - footer_height - 5 
        footer_point1 = fitz.Point(footer_x1, footer_y1)
        page.insert_text(footer_point1, footer_sentence, fontsize=10, color=(0, 0, 0))

        if footer_width in width_mapping:
            footer_x2 = width_mapping[footer_width] - 100 
        else:
            footer_x2 = footer_width / 2 - 150
        footer_y2 = page.rect.height - footer_height + 5 
        footer_point2 = fitz.Point(footer_x2, footer_y2)
        page.insert_text(footer_point2, footer_notice, fontsize=10, color=(0, 0, 0))

    document.save("result.pdf")




def make_pattern_with_star(first_value):
    pattern = re.compile(r"\b{}\w*\b".format(re.escape(first_value)), re.IGNORECASE)
    return pattern


def make_pattern_without_star(first_value):
    pattern = re.compile(r"\b{}\b".format(re.escape(first_value)), re.IGNORECASE)
    return pattern



def remove_blank_pages(doc):
    page_numbers_to_delete = []

    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        text = page.get_text()
        # Check if page is blank by checking if text is empty or contains only whitespace
        if not text.strip():
            page_numbers_to_delete.append(page_num)

    # Deleting pages in reverse order to avoid renumbering issues
    for page_num in reversed(page_numbers_to_delete):
        doc.delete_page(page_num)



def log_coordinates(key, page_number, x, y):
    pass



def highlight_single(pattern, key, color_index):
    for page in document.pages():
        page_text  = page.get_text()
        sentences = re.split(r'\.|\n \n', page_text)

        # Remove any empty strings from the list
        sentences = [sentence.strip() for sentence in sentences if sentence.strip()]
        for sentence in sentences:
            # colors = color_list[color_index % len(color_list)]
            # color_index += 1
            rect1 = page.search_for(key)
            if re.search(pattern, sentence):
                rect = page.search_for(sentence)
                if rect and rect not in temp:  # Check if rect is not None and not already processed
                    highlighted = page.add_highlight_annot(rect)
                    highlighted.set_colors(
                        {"stroke": highlighted_sentences[key]["color_list"], "fill": (0.75, 0.8, 0.95)}
                    )
                    highlighted.update()
                    temp.append(rect)
                    highlighted_sentences[key]["page_list"].append(
                        (page.number, sentence.strip())
                    )
                    
                    # # Print coordinates of rect
                    
                    # print(f"Coordinates for key '{key}': {rect}")
                    # print(f"Coordinates for key '{sentence}': {rect}")

                if rect:
                    avg_y = (rect[0].y1 + rect[0].y0) / 1.95
                    if (page.number, avg_y) in verticalheight:
                        avg_y = ((rect[0].y1 + rect[0].y0) / 1.95) + 10

                    if (key, page.number + 1, 650, 650) not in [
                        coord for coord in verticalheight if coord[0] == key
                    ]:
                        page.insert_text(
                            (650, avg_y), key, fontsize=12, color=highlighted_sentences[key]["color_list"], rotate=0
                        )
                        x, y = 650, avg_y
                        verticalheight.append((page.number, avg_y))
                        log_coordinates(key, page.number + 1, x, y)

def highlight_triple(pattern1, pattern2, steps, key, color_index):
    for page in document.pages():
        page_text = page.get_text()
        sentences = re.split(r'\.|\n \n', page_text)

        # Remove any empty strings from the list
        sentences = [sentence.strip() for sentence in sentences if sentence.strip()]
        for sentence in sentences:
            word_list = sentence.split(" ")
            merge_patterns = [pattern1, pattern2]
            results = []
            checked_pic = []
            # colors = color_list[color_index % len(color_list)]
            # color_index += 1
            for i, word in enumerate(word_list):
                for pickpattern in merge_patterns:
                    if pickpattern.lower() in word.lower():
                        if pickpattern not in checked_pic:
                            results.append((i, word, merge_patterns))
                            checked_pic.append(pickpattern)
            if len(results) >= 2 and (abs(results[1][0] - results[0][0]) <= steps):
                rect = page.search_for(sentence)
                if rect and rect not in temp:  # Check if rect is not None and not already processed
                    highlighted = page.add_highlight_annot(rect)
                    highlighted.set_colors(
                        {"stroke": highlighted_sentences[key]["color_list"], "fill": (0.75, 0.8, 0.95)}
                    )
                    highlighted.update()
                    temp.append(rect)
                    highlighted_sentences[key]["page_list"].append(
                        (page.number, sentence.strip())
                    )
                    # Print coordinates of rect
                    
                    # print(f"Coordinates for key '{key}': {rect}")
                    # print(f"Coordinates for key '{sentence}': {rect}")
                    if rect:
                        avg_y = (rect[0].y1 + rect[0].y0) / 1.95
                        if (page.number, avg_y) in verticalheight:
                            avg_y = ((rect[0].y1 + rect[0].y0) / 1.95) + 10

                        if (key, page.number + 1, 650, 650) not in [
                            coord for coord in verticalheight if coord[0] == key
                        ]:
                            page.insert_text(
                                (650, avg_y), key, fontsize=12, color=highlighted_sentences[key]["color_list"], rotate=0
                            )
                            x, y = 650, avg_y
                            verticalheight.append((page.number, avg_y))
                            log_coordinates(key, page.number + 1, x, y)


def highlight_fifth(pattern1, pattern2, pattern3, steps1, steps2, key, color_index):
    for page in document.pages():
        page_text = page.get_text()
        sentences = re.split(r'\.|\n \n', page_text)

        # Remove any empty strings from the list
        sentences = [sentence.strip() for sentence in sentences if sentence.strip()]
        for sentence in sentences:
            word_list = sentence.split(" ")
            merge_patterns = [pattern1, pattern2, pattern3]
            results = []
            checked_pic = []

            # colors = color_list[color_index % len(color_list)]
            # color_index += 1
            for i, word in enumerate(word_list):
                for pickpattern in merge_patterns:
                    if pickpattern.lower() in word.lower():
                        if pickpattern not in checked_pic:
                            results.append((i, word, merge_patterns))
                            checked_pic.append(pickpattern)
            if (
                len(results) == 3
                and (results[1][0] - results[0][0] <= steps1)
                and (results[2][0] - results[1][0] <= steps2)
            ):
                rect = page.search_for(sentence)
                if rect and rect not in temp:  # Check if rect is not None and not already processed
                    highlighted = page.add_highlight_annot(rect)
                    highlighted.set_colors(
                        {"stroke": highlighted_sentences[key]["color_list"], "fill": (0.75, 0.8, 0.95)}
                    )
                    highlighted.update()
                    temp.append(rect)
                    highlighted_sentences[key]["page_list"].append(
                        (page.number, sentence.strip())
                    )
                    # # Print coordinates of rect
                    # print(f"Coordinates for key '{key}': {rect}")
                    # print(f"Coordinates for key '{sentence}': {rect}")
                    if rect:
                        avg_y = (rect[0].y1 + rect[0].y0) / 1.95
                        if (page.number, avg_y) in verticalheight:
                            avg_y = ((rect[0].y1 + rect[0].y0) / 1.95) + 10

                        if (key, page.number + 1, 650, 650) not in [
                            coord for coord in verticalheight if coord[0] == key
                        ]:
                            page.insert_text(
                                (650, avg_y), key, fontsize=12, color=highlighted_sentences[key]["color_list"], rotate=0
                            )
                            x, y = 650, avg_y
                            verticalheight.append((page.number, avg_y))
                            log_coordinates(key, page.number + 1, x, y)

def create_from_json(loaded_keyword_data, color_index):
    for key, values in loaded_keyword_data.items():
        for value_key, values_value in values.items():
            if len(values_value) == 1:
                if "*" in values_value[0]:
                    single_length_keyword = make_pattern_with_star(values_value[0])
                    highlight_single(single_length_keyword, key, color_index)
                else:
                    single_length_keyword = make_pattern_without_star(values_value[0])
                    highlight_single(single_length_keyword, key, color_index)
            if len(values_value) == 3:
                if "*" in values_value[0] and "*" not in values_value[2]:
                    highlight_triple(
                        values_value[0].replace("*", ""),
                        values_value[2],
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
                elif "*" not in values_value[0] and "*" not in values_value[2]:
                    highlight_triple(
                        values_value[0],
                        values_value[2],
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
                elif "*" in values_value[0] and "*" in values_value[2]:
                    highlight_triple(
                        values_value[0].replace("*", ""),
                        values_value[2].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
                elif "*" not in values_value[0] and "*" in values_value[2]:
                    highlight_triple(
                        values_value[0],
                        values_value[2].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
            if len(values_value) == 5:
                if (
                    "*" not in values_value[0]
                    and "*" not in values_value[2]
                    and "*" not in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0],
                        values_value[2],
                        values_value[4],
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" not in values_value[0]
                    and "*" in values_value[2]
                    and "*" in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0],
                        values_value[2].replace("*", ""),
                        values_value[4].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" in values_value[0]
                    and "*" not in values_value[2]
                    and "*" in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0].replace("*", ""),
                        values_value[2],
                        values_value[4].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" in values_value[0]
                    and "*" not in values_value[2]
                    and "*" not in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0].replace("*", ""),
                        values_value[2],
                        values_value[4],
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" not in values_value[0]
                    and "*" not in values_value[2]
                    and "*" in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0],
                        values_value[2],
                        values_value[4].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )

def create_main_pages(highlighted_sentences):
    links = ""
    group_sections = ""
    # first_page = document[0]
    # total_lines_needed = sum(
    #     len(highlighted_sentences[key]) + 1 for key in highlighted_sentences
    # )  # +1 for each key
    for key, value in highlighted_sentences.items():

        # Step 2: Group the texts by their first index using a dictionary

        grouped_excerpts = {}

        for excerpt in value["page_list"]:
            idx, text = excerpt
            if idx not in grouped_excerpts:
                grouped_excerpts[idx] = []
            grouped_excerpts[idx].append(text)

        # Step 3: Convert the dictionary into a list of tuples for the final output
        final_output = [(idx, texts) for idx, texts in grouped_excerpts.items()]

        if len(final_output):
            keyword_section = parent_ul_tag(final_output)

            group_sections += (
                value["title"]
                + value["description"]
                + found_reference(len(final_output))
                + keyword_section
                + "<hr />"
            )
        else:
            group_sections += (
                value["title"] + value["description"] + not_found_ref + "<hr />"
            )


    # for _ in range(3):
    #     document.insert_page(0)
    text = main_page_text + group_sections + disclaimer
    page = document.new_page()
    rect = page.rect + (36, 36, -36, -36)

    MEDIABOX = fitz.Rect(0,0,595,860)
    footer_height = 38  # Example footer height

    # Adjust A4 paper size to accommodate header and footer
    WHERE = fitz.Rect(MEDIABOX.tl.x +36 , MEDIABOX.tl.y+60 , MEDIABOX.br.x-36, MEDIABOX.br.y - 60)
    # we must specify an Archive because of the image
    # page.insert_htmlbox(rect, text, archive=fitz.Archive("."))
    story = fitz.Story(html=text)  # create story from HTML
    writer = fitz.DocumentWriter("output.pdf")  # create the writer

    more = 1  # will indicate end of input once it is set to 0

    while more:  # loop outputting the story
        device = writer.begin_page(MEDIABOX)  # make new page
        more, _ = story.place(WHERE)  # layout into allowed rectangle
        story.draw(device)  # write on page
        writer.end_page()  # finish page

    writer.close()


if __name__ == "__main__":
    temp = []
    y_dict = {}
    color_index = 0
    verticalheight = []
    annotated_coordinates = {}





    document = fitz.Document("Contract 6 - Unreviewed.pdf")
    with open("keywords.json", "r") as fp:
        loaded_keyword_data = json.load(fp)


    main_page_keys = {
        "consequential_damages": {
            "count": 0,
            "page_list": [],
            "color_list": (0.102, 0.737, 0.612),
            "title": "<h2>Consequential Damages</h2>",
            "description": "<p>There are many types of damages that could flow from a breach of contract, possibly the costliest being consequential damages. These are damages like lost profits, business interruption, and loss of goodwill. Including a waiver of consequential damages may mitigate those potential claims. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on consequential damages.</a></p>",
        },
        "delays": {
            "count": 0,
            "page_list": [],
            "color_list": (0.18, 0.8, 0.443),

            "title": "<h2>Delays</h2>",
            "description": "<p>Many contracts include a 'no damage for delay' clause which may limit recovery to additional time in lieu of more money. In the absences of delay provisions, claims for time and compensation are possible, subject to proper and timely notice. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on delays</a></p>",
        },
        "hazardous_materials": {
            "count": 0,
            "page_list": [],
            "color_list":(0.933, 0.714, 0.384),
            "title": "<h2>Hazardous materials</h2>",
            "description": "<p>Hazardous materials are defined by the U.S. Department of Transportation as any material that poses a risk tohealth, safety. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on hazardous materials</a></p>",
        },
        "hidden_conditions": {
            "count": 0,
            "page_list": [],
            "color_list":(0.988, 0.655, 0.875),
            "title": "<h2>Hidden Conditions</h2>",
            "description": "<p>Many contracts include provisions reaffirming a party's inspection and knowledge of the project site, thereby limiting claims for hidden conditions. In their absence, claims for unforeseen conditions are possible, subject to proper and timely notice. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on hidden conditions.</a></p>",
        },
        "indemnity": {
            "count": 0,
            "page_list": [],
            "color_list": (0.204, 0.596, 0.859),
            "title": "<h2>Indemnity and Defense</h2>",
            "description": "<p>Subject to some limitations, indemnity provisions pass actual or threatened liability or claims from one party to another, possibly including retention of legal counsel for another party. Insurance may not cover some or all of these obligations. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on indemnity.</a></p>",
        },
        "liability_caps": {
            "count": 0,
            "page_list": [],
            "color_list":(0.729, 0.451, 0.941),
            "title": "<h2>Liability Caps</h2>",
            "description": "<p>One way to manage risk is to place a cap on some or all types of damages. In the absence of a cap, then damages may be limitless. As a result, having a cap, even if high, it likely better than no cap. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on damage caps.</a></p>",
        },
        "liquidated_damages": {
            "count": 0,
            "page_list": [],
            "color_list":(0.624, 0.808, 0.525),
            "title": "<h2>Liquidated Damages</h2>",
            "description": "<p>Some contracts fix, or liquidate, certain types of damages in a contract, for example, $500 a day for delay. In the absence of such a provision, the parties are usually left to prove their actual damages. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on liquidated damages.</a></p>",
        },
        "notice_and_opp_to_cure": {
            "count": 0,
            "page_list": [],
            "color_list":(1.0, 1.0, 0.0),
            "title": "<h2>Notice and Opportunity to Cure</h2>",
            "description": "<p>In the absence of a specific notice provision, the law will usually impose a 'reasonable' amount of time based on the facts and circumstances. However, many contracts have specific notice provisions for claims and backcharges. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on notice to cure.</a></p>",
        },
        "pay_if_paid": {
            "count": 0,
            "page_list": [],
            "color_list":(0.902, 0.494, 0.133),
            "title": "<h2>Pay If Paid / Pay When Paid</h2>",
            "description": "<p>This provision shifts the risk of nonpayment from one party to another and is most common in subcontracts and sub- subcontracts. Certain 'magic language' like 'condition precedent' or 'contingent upon' is usually required to make it enforceable. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on pay when paid.</a></p>",
        },
        "price_escalation": {
            "count": 0,
            "page_list": [],
            "color_list":(1.0, 0.973, 0.49),
            "title": "<h2>Price Escalation</h2>",
            "description": "<p>A contract's price is most likely firm, even when the cost of labor and materials increase. Some contracts have provisions that specifically prohibit price increases. A price escalation provision may allow for claims for additional compensation as material and labor prices increase. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions onprice escalation</a></p>",
        },
        "stop_work": {
            "count": 0,
            "page_list": [],
            "color_list":(0.906, 0.298, 0.235),
            "title": "<h2>Right to Stop Work</h2>",
            "description": "<p>Many contracts preclude work stoppage even upon nonpayment or other disputes. If the contract is silent on this issue, that does not mean the right to stop work is assured. Having the express right to stop work can mitigate losses during a dispute. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on the right to stop work.</a></p>",
        },
    }

    highlighted_sentences = {}
    for key in loaded_keyword_data.keys():
        highlighted_sentences[key] = {**main_page_keys[key]}

    create_from_json(loaded_keyword_data, color_index)



    # for page in document.pages(): 
    #     if page.mediabox.width < 842:  # Check if the page width is less than 842
    #         rect = fitz.Rect(0, -90, 842,page.mediabox.height)  # Only create a new rect if needed
    #         page.set_mediabox(rect)


    for page in document:
        width = page.mediabox.width
        height = page.mediabox.height
        
        # Check if the page width is less than 842
        if width < 842:
            # Create a new rectangle with increased height
            new_rect = fitz.Rect(0, -70, 842, height)
            # Set the new mediabox with increased height
            page.set_mediabox(new_rect)
        else:
            # Create a new rectangle with the same width and increased height
            new_rect = fitz.Rect(0, -70, width, height )
            # Set the new mediabox with increased height
            page.set_mediabox(new_rect)

    create_main_pages(highlighted_sentences)
    print(highlighted_sentences,"0000000000000000000000000000000000000000000")
    document.save("output1.pdf")



result = fitz.open()
for pdf in ['output.pdf', 'output1.pdf']:
    with fitz.open(pdf) as mfile:
        result.insert_pdf(mfile)
remove_blank_pages(result)

def increment_page_number(document, output_path):
    # Loop through the first 5 pages
    for page_num in range(len(fitz.open("output.pdf"))):
        page = document[page_num]
        text = page.get_text("text")
        c = []
        
        # Find all occurrences of "Page x" in the text
        matches = re.findall(r'\bPage (\d+)\b', text, re.IGNORECASE)        # Process each match
        for match in matches:
            c.append(match)
            original_page_number = match
            incremented_page_number = str(int(original_page_number) + len(fitz.open(fitz.open("output.pdf"))))
            pattern = re.compile(r'\bPage ' + original_page_number + r'\b', re.IGNORECASE)

            
            # Replace the original page number with the incremented page number in the extracted text
            
            # Extract the text position and font details for replacement
            blocks = page.get_text("dict")["blocks"]
            for b in blocks:
                if b["type"] == 0:  # block contains text
                    for line in b["lines"]:
                        for span in line["spans"]:
                            if pattern.search(span["text"]):
                                x0, y0, x1, y1 = span["bbox"]
                                fontname = "Helvetica"
                                fontsize = span["size"]
                                
                                if len(c)%2 == 1:
                                # Insert the new text
                                    page.add_redact_annot([x0, y0, x1, y1], fill=(1, 1, 1))
                                    page.apply_redactions()
                                    page.insert_text((76.0,y0+12), 'Page ' + incremented_page_number, fontname=fontname, fontsize = fontsize)
                                    c.append(incremented_page_number)
    document.save(output_path)

# Example usage
increment_page_number(result, 'output5.pdf')

result = fitz.open("output5.pdf")
footer_apply(result)

def key_to_title_string(main_page_keys, key):
    # Check if the key exists in the dictionary
    if key in main_page_keys:
        # Extract the title from the dictionary
        dictionary_title = main_page_keys[key]['title']
        # Remove the HTML tags from the dictionary title
        title_string = dictionary_title.replace("<h2>", "").replace("</h2>", "")
        return title_string
    else:
        # If the key does not exist, return None or an appropriate message
        return None


main_page_keys = {
    "consequential_damages": {
        "count": 0,
        "page_list": [],
        "color_list": (0.102, 0.737, 0.612),
        "title": "<h2>Consequential Damages</h2>",
        "description": "<p>There are many types of damages that could flow from a breach of contract, possibly the costliest being consequential damages. These are damages like lost profits, business interruption, and loss of goodwill. Including a waiver of consequential damages may mitigate those potential claims. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on consequential damages.</a></p>",
    },
    "delays": {
        "count": 0,
        "page_list": [],
        "color_list":(0.18, 0.8, 0.443),
        "title": "<h2>Delays</h2>",
        "description": "<p>Many contracts include a 'no damage for delay' clause which may limit recovery to additional time in lieu of more money. In the absences of delay provisions, claims for time and compensation are possible, subject to proper and timely notice. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on delays</a></p>",
    },
    "hazardous_materials": {
        "count": 0,
        "page_list": [],
        "color_list":(0.933, 0.714, 0.384),
        "title": "<h2>Hazardous materials</h2>",
        "description": "<p>Hazardous materials are defined by the U.S. Department of Transportation as any material that poses a risk tohealth, safety. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on hazardous materials</a></p>",
    },
    "hidden_conditions": {
        "count": 0,
        "page_list": [],
        "color_list":(0.988, 0.655, 0.875),
        "title": "<h2>Hidden Conditions</h2>",
        "description": "<p>Many contracts include provisions reaffirming a party's inspection and knowledge of the project site, thereby limiting claims for hidden conditions. In their absence, claims for unforeseen conditions are possible, subject to proper and timely notice. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on hidden conditions.</a></p>",
    },
    "indemnity": {
        "count": 0,
        "page_list": [],
        "color_list": (0.204, 0.596, 0.859),
        "title": "<h2>Indemnity and Defense</h2>",
        "description": "<p>Subject to some limitations, indemnity provisions pass actual or threatened liability or claims from one party to another, possibly including retention of legal counsel for another party. Insurance may not cover some or all of these obligations. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on indemnity.</a></p>",
    },
    "liability_caps": {
        "count": 0,
        "page_list": [],
        "color_list":(0.729, 0.451, 0.941),
        "title": "<h2>Liability Caps</h2>",
        "description": "<p>One way to manage risk is to place a cap on some or all types of damages. In the absence of a cap, then damages may be limitless. As a result, having a cap, even if high, it likely better than no cap. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on damage caps.</a></p>",
    },
    "liquidated_damages": {
        "count": 0,
        "page_list": [],
        "color_list":(0.624, 0.808, 0.525),
        "title": "<h2>Liquidated Damages</h2>",
        "description": "<p>Some contracts fix, or liquidate, certain types of damages in a contract, for example, $500 a day for delay. In the absence of such a provision, the parties are usually left to prove their actual damages. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on liquidated damages.</a></p>",
    },
    "notice_and_opp_to_cure": {
        "count": 0,
        "page_list": [],
        "color_list":(1.0, 1.0, 0.0),
        "title": "<h2>Notice and Opportunity to Cure</h2>",
        "description": "<p>In the absence of a specific notice provision, the law will usually impose a 'reasonable' amount of time based on the facts and circumstances. However, many contracts have specific notice provisions for claims and backcharges. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on notice to cure.</a></p>",
    },
    "pay_if_paid": {
        "count": 0,
        "page_list": [],
        "color_list":(0.902, 0.494, 0.133),
        "title": "<h2>Pay If Paid / Pay When Paid</h2>",
        "description": "<p>This provision shifts the risk of nonpayment from one party to another and is most common in subcontracts and sub- subcontracts. Certain 'magic language' like 'condition precedent' or 'contingent upon' is usually required to make it enforceable. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on pay when paid.</a></p>",
    },
    "price_escalation": {
        "count": 0,
        "page_list": [],
        "color_list":(1.0, 0.973, 0.49),
        "title": "<h2>Price Escalation</h2>",
        "description": "<p>A contract's price is most likely firm, even when the cost of labor and materials increase. Some contracts have provisions that specifically prohibit price increases. A price escalation provision may allow for claims for additional compensation as material and labor prices increase. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions onprice escalation</a></p>",
    },
    "stop_work": {
        "count": 0,
        "page_list": [],
        "color_list":(0.906, 0.298, 0.235),
        "title": "<h2>Right to Stop Work</h2>",
        "description": "<p>Many contracts preclude work stoppage even upon nonpayment or other disputes. If the contract is silent on this issue, that does not mean the right to stop work is assured. Having the express right to stop work can mitigate losses during a dispute. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on the right to stop work.</a></p>",
    },
}




def remove_trailing_newline(s):
    # Split the string by newline characters
    lines = s.split('\n')
    
    # Remove empty strings resulting from consecutive newline characters
    non_empty_lines = [line for line in lines if line.strip()]
    
    # Return the first non-empty line, or an empty string if all lines were empty
    return non_empty_lines[0] if non_empty_lines else ''

def find_text_page(pdf_path, search_text, start_page=0, end_page=6):
 
    pdf_document = fitz.open(pdf_path)
    for page_number in range(end_page):
        page = pdf_document.load_page(page_number)
        text_blocks = page.get_text("blocks")
        for block in text_blocks:

            if key_to_title_string(main_page_keys, search_text) in block[4]:

                return page_number
                
    return None


def add_links_to_position(pdf_path, output_path, x_value):
    # Open the PDF file
    pdf_document = fitz.open(pdf_path)
    c = []
    # Iterate through all pages
    for page_number in range(pdf_document.page_count):
        page = pdf_document.load_page(page_number)
        
        # Get the text blocks on the page
        text_blocks = page.get_text("blocks")
        
        for block in text_blocks:
            # Each block is a tuple: (x0, y0, x1, y1, text, block_no, block_type)
            x0, y0, x1, y1, text, block_no, block_type = block
            avg_y = ((y0 + y1) / 1.95) + 15  # Calculate avg_y and adjust it
            
            if int(x0) == x_value:

                a = remove_trailing_newline(block[4])
                if a not in c:
                    link_target_page = find_text_page("result.pdf",a, start_page=0, end_page=len(fitz.open("output.pdf")))
                    c.append(a)
                    c.append(link_target_page)
                else:
                    for i in range(0,len(c)):
                        if c[i] == a:
                            link_target_page = c[i+1]
                rect = fitz.Rect(x0, y0, x1, y1)
                
                # Add the link to the rectangle
                page.insert_link({
                    "from": rect,  # The rectangle around the text
                    "kind": fitz.LINK_GOTO,  # Internal link
                    "page": link_target_page,  # Page to link to (0-based index)
                    "to": fitz.Point(0, 0)  # Top-left corner of the target page
                })
    
    # Save the modified PDF to the output path
    pdf_document.save(output_path)
    pdf_document.close()


add_links_to_position("result.pdf", "contract_final.pdf",650)



def remove_all_spaces(text):
    x = text.replace(' ','')
    z = x.replace('ﬁ','fi')
    y =z.replace('\n','')
    a = y.replace('ﬂ','fl')
    b = a.replace('ﬃ','ffi')
    c = b.replace('ﬀ','ff')
    return c  

def find_matching_sentences(pdf_path, target_text):
    matching_pages = []
    doc = fitz.open(pdf_path)
    
    # Iterate through the pages starting from the specified page
    for page_number in range(len(fitz.open("output.pdf")),len(doc)):
        page = doc[page_number]
        page_text = page.get_text()
        a = remove_all_spaces(page_text)
        b = remove_all_spaces(target_text)
        # Search for the target text in the page tex
        if b in a:
            matching_pages.append(page_number) 
    return matching_pages

def add_links_to_sentences_after_marker(pdf_path, output_path, marker='○'):
    # Open the PDF file
    a = []
    pdf_document = fitz.open(pdf_path)
    
    # Iterate through all pages
    for page_number in range(pdf_document.page_count):
        c = []
        page = pdf_document.load_page(page_number)
        
        # Get the text of the page
        page_text = page.get_text()
        
        # Find all occurrences of the marker
        marker_indices = [m.start() for m in re.finditer(re.escape(marker), page_text)]
        # Iterate through marker indices
        for idx in marker_indices:
            # Find the end of the line or paragraph after the marker
            end_index = page_text.find('\n', idx)
            if end_index == -1:
                end_index = len(page_text)
            
            # Extract the text after the marker
            text_after_marker = page_text[idx + len(marker): end_index]
            
            # Skip if there's no text after the marker
            if not text_after_marker.strip():
                continue
            # Find the page numbers with matching sentences
            matching_pages = find_matching_sentences(pdf_path, text_after_marker)

            
            # If matching pages are found, add links
            for target_page in matching_pages:
                # Create a rectangle for the link (around the text after the marker)
                rect = fitz.Rect(0, 0, 0, 0)
                text_instances = page.search_for(text_after_marker)
                if text_instances:
                    for i in range(0,len(text_instances)):
                        if text_instances[i][:4] not in c:
                            rect = fitz.Rect(text_instances[i][:4])
                            c.append(rect)
                

                            if rect != fitz.Rect(0, 0, 0, 0):
                                page.insert_link({
                                    "from": rect,  # The rectangle around the text after the marker
                                    "kind": fitz.LINK_GOTO,  # Internal link
                                    "page": target_page,  # Page to link to (0-based index)
                                    "to": fitz.Point(0, 0)  # Top-left corner of the target page
                                })
    
    # Save the modified PDF to the output path
    pdf_document.save(output_path)
    pdf_document.close()


pdf_path = 'contract_final.pdf'
output_path = 'final.pdf'
marker = '○'

add_links_to_sentences_after_marker(pdf_path, output_path, marker)
result.close()


def add_links_to_page_numbers(input_pdf, output_pdf):
    # Open the input PDF
    pdf_document = fitz.open(input_pdf)

    # Iterate through each page of the PDF
    for page_number in range(len(fitz.open("output.pdf"))):
        c = []
        page = pdf_document.load_page(page_number)
        text = page.get_text()

        # Find instances of 'page' followed by a number
        matches = re.finditer(r'page (\d+)', text, re.IGNORECASE)
        matches = list(matches)[:-1]
        for match in matches:

            # Extract the page number
            target_page_number = int(match.group(1))
            # Add a link to the target pager
            rect = fitz.Rect(0, 0, 0, 0)
            # Extract the text from the match object
            match_text = match.group(0)
            text_instances = page.search_for(match_text)
            if text_instances:
                for i in range(0,len(text_instances)):
                    if text_instances[i][:4] not in c:
                        rect = fitz.Rect(text_instances[i][:4])
                        c.append(rect)
            
            # Add the link to the rectangle
                        if rect != fitz.Rect(0, 0, 0, 0):
                            page.insert_link({
                                "from": rect,  # The rectangle around the text after the marker
                                "kind": fitz.LINK_GOTO,  # Internal link
                                "page": target_page_number - 1,  # Page to link to (0-based index)
                                "to": fitz.Point(0, 0)  # Top-left corner of the target page
                            })
    # Save the modified PDF to the output file
    pdf_document.save(output_pdf)
    pdf_document.close()
    print(f"Modified PDF saved as '{output_pdf}'.")
input_pdf = "final.pdf"  # Replace with the path to your input PDF file
output_pdf = "contractor_final-66666.pdf"  # Replace with the desired path for the output PDF file
add_links_to_page_numbers(input_pdf, output_pdf)


os.remove('contract_final.pdf')
os.remove("result.pdf")
os.remove("output.pdf")
os.remove("output1.pdf")
os.remove("final.pdf")
os.remove("output5.pdf")
