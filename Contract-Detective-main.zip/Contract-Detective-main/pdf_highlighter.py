import fitz
import json
import re
from utils import (
    text as main_page_text,
    found_reference,
    not_found_ref,
    parent_ul_tag,
    disclaimer,
)


def make_pattern_with_star(first_value):
    pattern = re.compile(r"\b{}\w*\b".format(re.escape(first_value)), re.IGNORECASE)
    return pattern


def make_pattern_without_star(first_value):
    pattern = re.compile(r"\b{}\b".format(re.escape(first_value)), re.IGNORECASE)
    return pattern


def log_coordinates(key, page_number, x, y):
    # print(f"Key: {key}, Page: {page_number}, Coordinates: ({x}, {y})")
    pass


def highlight_single(pattern, key, color_index):
    for page in document.pages():
        page_text = page.get_text()
        for sentence in page_text.split("."):
            sentence = sentence.strip()

            colors = color_list[color_index % len(color_list)]
            color_index += 1
            if re.search(pattern, sentence):
                rect = page.search_for(sentence)
                if rect not in temp:
                    highlighted = page.add_highlight_annot(rect)
                    # colors = (1, 0, 0)
                    highlighted.set_colors(
                        {"stroke": colors, "fill": (0.75, 0.8, 0.95)}
                    )
                    highlighted.update()
                    temp.append(rect)
                    highlighted_sentences[key]["page_list"].append(
                        (page.number, sentence.strip())
                    )

                if rect:
                    avg_y = (rect[0].y1 + rect[0].y0) / 1.95
                    # print(avg_y, verticalheight, "8888888888")
                    if (page.number, avg_y) in verticalheight:
                        avg_y = ((rect[0].y1 + rect[0].y0) / 1.95) + 15

                    # Check if the keyword is already in the list of coordinates
                    if (key, page.number + 1, 650, 650) not in [
                        coord for coord in verticalheight if coord[0] == key
                    ]:
                        page.insert_text(
                            (650, avg_y), key, fontsize=12, color=colors, rotate=0
                        )
                        x, y = 650, avg_y
                        verticalheight.append((page.number, avg_y))
                        log_coordinates(key, page.number + 1, x, y)


def highlight_triple(pattern1, pattern2, steps, key, color_index):

    for page in document.pages():
        page_text = page.get_text()
        for sentence in page_text.split("."):
            sentence = sentence.strip()
            word_list = sentence.split(" ")
            merge_patterns = [pattern1, pattern2]
            results = []
            checked_pic = []
            # print(color_index,"9999999")
            colors = color_list[color_index % len(color_list)]
            color_index += 1
            for i, word in enumerate(word_list):
                for pickpattern in merge_patterns:
                    if pickpattern.lower() in word.lower():
                        if pickpattern not in checked_pic:
                            results.append((i, word, merge_patterns))
                            checked_pic.append(pickpattern)
            if len(results) >= 2 and (abs(results[1][0] - results[0][0]) <= steps):
                rect = page.search_for(sentence)
                if rect not in temp:
                    highlighted = page.add_highlight_annot(rect)
                    # colors1 = (0, 1, 0)
                    highlighted.set_colors(
                        {"stroke": colors, "fill": (0.75, 0.8, 0.95)}
                    )
                    highlighted.update()
                    temp.append(rect)
                    highlighted_sentences[key]["page_list"].append(
                        (page.number, sentence.strip())
                    )
                    if rect:
                        avg_y = (rect[0].y1 + rect[0].y0) / 1.95
                        # print(avg_y, verticalheight, "8888888888")
                        if (page.number, avg_y) in verticalheight:
                            avg_y = ((rect[0].y1 + rect[0].y0) / 1.95) + 15

                        # Check if the keyword is already in the list of coordinates
                        if (key, page.number + 1, 650, 650) not in [
                            coord for coord in verticalheight if coord[0] == key
                        ]:
                            page.insert_text(
                                (650, avg_y), key, fontsize=12, color=colors, rotate=0
                            )
                            x, y = 650, avg_y
                            verticalheight.append((page.number, avg_y))
                            log_coordinates(key, page.number + 1, x, y)


def highlight_fifth(pattern1, pattern2, pattern3, steps1, steps2, key, color_index):
    for page in document.pages():
        page_text = page.get_text()
        for sentence in page_text.split("."):
            sentence = sentence.strip()
            word_list = sentence.split(" ")
            merge_patterns = [pattern1, pattern2, pattern3]
            results = []
            checked_pic = []

            colors = color_list[color_index % len(color_list)]
            color_index += 1
            for i, word in enumerate(word_list):
                for pickpattern in merge_patterns:
                    if pickpattern.lower() in word.lower():
                        if pickpattern not in checked_pic:
                            results.append((i, word, merge_patterns))
                            checked_pic.append(pickpattern)
            if (
                len(results) == 3
                and (results[1][0] - results[0][0] <= steps1)
                and (results[2][0] - results[1][0] <= steps2)
            ):
                rect = page.search_for(sentence)
                if rect not in temp:

                    highlighted = page.add_highlight_annot(rect)
                    # colors2 = (0, 0, 1)
                    highlighted.set_colors(
                        {"stroke": colors, "fill": (0.75, 0.8, 0.95)}
                    )
                    highlighted.update()
                    temp.append(rect)
                    highlighted_sentences[key]["page_list"].append(
                        (page.number, sentence.strip())
                    )
                    if rect:
                        avg_y = (rect[0].y1 + rect[0].y0) / 1.95
                        # print(avg_y, verticalheight, "8888888888")
                        if (page.number, avg_y) in verticalheight:
                            avg_y = ((rect[0].y1 + rect[0].y0) / 1.95) + 15

                        # Check if the keyword is already in the list of coordinates
                        if (key, page.number + 1, 650, 650) not in [
                            coord for coord in verticalheight if coord[0] == key
                        ]:
                            page.insert_text(
                                (650, avg_y), key, fontsize=12, color=colors, rotate=0
                            )
                            x, y = 650, avg_y
                            verticalheight.append((page.number, avg_y))
                            log_coordinates(key, page.number + 1, x, y)


def create_from_json(loaded_keyword_data, color_index):
    for key, values in loaded_keyword_data.items():
        for value_key, values_value in values.items():
            if len(values_value) == 1:
                if "*" in values_value[0]:
                    single_length_keyword = make_pattern_with_star(values_value[0])
                    highlight_single(single_length_keyword, key, color_index)
                else:
                    single_length_keyword = make_pattern_without_star(values_value[0])
                    highlight_single(single_length_keyword, key, color_index)
            if len(values_value) == 3:
                if "*" in values_value[0] and "*" not in values_value[2]:
                    highlight_triple(
                        values_value[0].replace("*", ""),
                        values_value[2],
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
                elif "*" not in values_value[0] and "*" not in values_value[2]:
                    highlight_triple(
                        values_value[0],
                        values_value[2],
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
                elif "*" in values_value[0] and "*" in values_value[2]:
                    highlight_triple(
                        values_value[0].replace("*", ""),
                        values_value[2].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
                elif "*" not in values_value[0] and "*" in values_value[2]:
                    highlight_triple(
                        values_value[0],
                        values_value[2].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        key,
                        color_index,
                    )
            if len(values_value) == 5:
                if (
                    "*" not in values_value[0]
                    and "*" not in values_value[2]
                    and "*" not in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0],
                        values_value[2],
                        values_value[4],
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" not in values_value[0]
                    and "*" in values_value[2]
                    and "*" in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0],
                        values_value[2].replace("*", ""),
                        values_value[4].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" in values_value[0]
                    and "*" not in values_value[2]
                    and "*" in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0].replace("*", ""),
                        values_value[2],
                        values_value[4].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" in values_value[0]
                    and "*" not in values_value[2]
                    and "*" not in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0].replace("*", ""),
                        values_value[2],
                        values_value[4],
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )
                elif (
                    "*" not in values_value[0]
                    and "*" not in values_value[2]
                    and "*" in values_value[4]
                ):
                    highlight_fifth(
                        values_value[0],
                        values_value[2],
                        values_value[4].replace("*", ""),
                        int(values_value[1].replace("/", "")),
                        int(values_value[3].replace("/", "")),
                        key,
                        color_index,
                    )


def create_main_pages(highlighted_sentences):
    links = ""
    group_sections = ""
    # first_page = document[0]
    # total_lines_needed = sum(
    #     len(highlighted_sentences[key]) + 1 for key in highlighted_sentences
    # )  # +1 for each key
    for key, value in highlighted_sentences.items():
        print(value, "ppppppppppppp")
        # Step 2: Group the texts by their first index using a dictionary

        grouped_excerpts = {}

        for excerpt in value["page_list"]:
            idx, text = excerpt
            if idx not in grouped_excerpts:
                grouped_excerpts[idx] = []
            grouped_excerpts[idx].append(text)

        # Step 3: Convert the dictionary into a list of tuples for the final output
        final_output = [(idx, texts) for idx, texts in grouped_excerpts.items()]

        if len(final_output):
            keyword_section = parent_ul_tag(final_output)

            group_sections += (
                value["title"]
                + value["description"]
                + found_reference(len(final_output))
                + keyword_section
            )
        else:
            group_sections += value["title"] + value["description"] + not_found_ref
        print(final_output, key, "oooooooooooooooooo")

    # for _ in range(3):
    #     document.insert_page(0)
    text = main_page_text + group_sections + disclaimer
    page = document.new_page()
    rect = page.rect + (36, 36, -36, -36)

    # we must specify an Archive because of the image
    page.insert_htmlbox(rect, text, archive=fitz.Archive("."))


if __name__ == "__main__":
    temp = []
    y_dict = {}
    color_index = 0
    verticalheight = []
    annotated_coordinates = {}

    color_list = [
        (1, 0, 0),
        (0, 0, 1),
        (1, 0, 1),
        (0, 1, 0),
    ]  # Add more colors as needed

    document = fitz.Document("./files/Contract 4 - Unreviewed.pdf")
    with open("keywords.json", "r") as fp:
        loaded_keyword_data = json.load(fp)

    main_page_keys = {
        "consequential_damages": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Consequential Damages</h2>",
            "description": "<p>There are many types of damages that could flow from a breach of contract, possibly the costliest being consequential damages. These are damages like lost profits, business interruption, and loss of goodwill. Including a waiver of consequential damages may mitigate those potential claims. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on consequential damages.</a></p>",
        },
        "delays": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Delays</h2>",
            "description": "<p>Many contracts include a 'no damage for delay' clause which may limit recovery to additional time in lieu of more money. In the absences of delay provisions, claims for time and compensation are possible, subject to proper and timely notice. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on delays</a></p>",
        },
        "hazardous_materials": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Hazardous materials</h2>",
            "description": "<p>Hazardous materials are defined by the U.S. Department of Transportation as any material that poses a risk tohealth, safety. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on hazardous materials</a></p>",
        },
        "hidden_conditions": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Hidden Conditions</h2>",
            "description": "<p>Many contracts include provisions reaffirming a party's inspection and knowledge of the project site, thereby limiting claims for hidden conditions. In their absence, claims for unforeseen conditions are possible, subject to proper and timely notice. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on hidden conditions.</a></p>",
        },
        "indemnity": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Indemnity and Defense</h2>",
            "description": "<p>Subject to some limitations, indemnity provisions pass actual or threatened liability or claims from one party to another, possibly including retention of legal counsel for another party. Insurance may not cover some or all of these obligations. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on indemnity.</a></p>",
        },
        "liability_caps": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Liability Caps</h2>",
            "description": "<p>One way to manage risk is to place a cap on some or all types of damages. In the absence of a cap, then damages may be limitless. As a result, having a cap, even if high, it likely better than no cap. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on damage caps.</a></p>",
        },
        "liquidated_damages": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Liquidated Damages</h2>",
            "description": "<p>Some contracts fix, or liquidate, certain types of damages in a contract, for example, $500 a day for delay. In the absence of such a provision, the parties are usually left to prove their actual damages. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on liquidated damages.</a></p>",
        },
        "notice_and_opp_to_cure": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Notice and Opportunity to Cure</h2>",
            "description": "<p>In the absence of a specific notice provision, the law will usually impose a 'reasonable' amount of time based on the facts and circumstances. However, many contracts have specific notice provisions for claims and backcharges. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on notice to cure.</a></p>",
        },
        "pay_if_paid": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Pay If Paid / Pay When Paid</h2>",
            "description": "<p>This provision shifts the risk of nonpayment from one party to another and is most common in subcontracts and sub- subcontracts. Certain 'magic language' like 'condition precedent' or 'contingent upon' is usually required to make it enforceable. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on pay when paid.</a></p>",
        },
        "price_escalation": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Price Escalation</h2>",
            "description": "<p>A contract's price is most likely firm, even when the cost of labor and materials increase. Some contracts have provisions that specifically prohibit price increases. A price escalation provision may allow for claims for additional compensation as material and labor prices increase. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions onprice escalation</a></p>",
        },
        "stop_work": {
            "count": 0,
            "page_list": [],
            "title": "<h2>Right to Stop Work</h2>",
            "description": "<p>Many contracts preclude work stoppage even upon nonpayment or other disputes. If the contract is silent on this issue, that does not mean the right to stop work is assured. Having the express right to stop work can mitigate losses during a dispute. <a href='https://www.artifex.com'> Click to watch a 5-minute video and read sample provisions on the right to stop work.</a></p>",
        },
    }

    highlighted_sentences = {}
    for key in loaded_keyword_data.keys():
        highlighted_sentences[key] = {**main_page_keys[key]}

    create_from_json(loaded_keyword_data, color_index)
    rect = fitz.Rect(0, 0, 842, document[0].mediabox.height)
    for page in document.pages():
        page.set_mediabox(rect)

    create_main_pages(highlighted_sentences)

    document.save("contractkeywords1.pdf")
