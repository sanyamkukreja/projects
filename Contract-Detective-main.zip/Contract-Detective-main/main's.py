from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse
import os
import shutil
import subprocess

app = FastAPI()

UPLOAD_DIRECTORY = "/tmp/uploaded_files"
MODIFIED_DIRECTORY = "/tmp/modified_files"

# Ensure the directories exist
os.makedirs(UPLOAD_DIRECTORY, exist_ok=True)
os.makedirs(MODIFIED_DIRECTORY, exist_ok=True)


@app.post("/upload-pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    # Save the uploaded file
    file_location = os.path.join(UPLOAD_DIRECTORY, file.filename)
    with open(file_location, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # Process the file
    modified_file_location = await process_pdf(file_location)

    return FileResponse(
        modified_file_location,
        media_type="application/pdf",
        filename=f"modified_{file.filename}",
    )


async def process_pdf(file_path: str) -> str:
    # Call the processing script
    modified_file_path = os.path.join(
        MODIFIED_DIRECTORY, f"modified_{os.path.basename(file_path)}"
    )
    subprocess.run(
        ["python3", "process_pdf.py", file_path, modified_file_path], check=True
    )
    return modified_file_path


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
