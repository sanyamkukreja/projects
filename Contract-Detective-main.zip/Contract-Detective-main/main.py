# from fastapi import FastAPI, File, UploadFile
# from fastapi.responses import FileResponse
# import os
# import shutil
# import subprocess
# from docx2pdf import convert

# app = FastAPI()

# UPLOAD_DIRECTORY = "/tmp/uploaded_files"
# MODIFIED_DIRECTORY = "/tmp/modified_files"

# # Ensure the directories exist
# os.makedirs(UPLOAD_DIRECTORY, exist_ok=True)
# os.makedirs(MODIFIED_DIRECTORY, exist_ok=True)


# @app.post("/upload-pdf/")
# async def upload_pdf(file: UploadFile = File(...)):
#     # Save the uploaded file
#     file_location = os.path.join(UPLOAD_DIRECTORY, file.filename)
#     with open(file_location, "wb") as f:
#         shutil.copyfileobj(file.file, f)

#     # Process the file
#     modified_file_location = await process_pdf(file_location)

#     return FileResponse(
#         modified_file_location,
#         media_type="application/pdf",
#         filename=f"modified_{file.filename}",
#     )


# async def process_pdf(file_path: str) -> str:
#      # Ensure the directories exist
#     os.makedirs(os.path.dirname(file_path), exist_ok=True)
#     # Call the processing script
#     ## Change the extension of the modified file path to .pdf
#     # base_name = os.path.basename(file_path)
#     # file_name, _ = os.path.splitext(base_name)
#     # modified_file_path = os.path.join(MODIFIED_DIRECTORY, f"modified_{file_name}.pdf")
#     # print(modified_file_path,"oooooooooooooooooooooooooooooooooo")
#     # try:
#     #     convert(file_path, modified_file_path)
#     #     print(f"Conversion successful, file saved at {modified_file_path}")
#     # except Exception as e:
#     #     print(f"Error during conversion: {e}")
#     #     raise
#     # subprocess.run(["python3", "perfect.py", file_path, modified_file_path], check=True)
#      # Convert .docx to .pdf
#     base_name = os.path.basename(file_path)
#     file_name, ext = os.path.splitext(base_name)
#     pdf_file_path = os.path.join(MODIFIED_DIRECTORY, f"{file_name}.pdf")

#     if ext.lower() == ".docx":
#         try:
#             convert(file_path, pdf_file_path)
#         except Exception as e:
#             raise
#     else:
#         print(f"Input file is not a .docx file: {file_path}")
#         raise ValueError("Input file must be a .docx file")
#     # Process the PDF file with perfect.py
#     modified_file_path = os.path.join(MODIFIED_DIRECTORY, f"modified_{file_name}.pdf")

#     try:
#         # Construct file paths using os.path.join
#         pdf_file_path = os.path.join(MODIFIED_DIRECTORY, f"{file_name}.pdf")
#         modified_file_path = os.path.join(MODIFIED_DIRECTORY, f"modified_{file_name}.pdf")
#         result = subprocess.run(
#             ["python3", "perfect.py", pdf_file_path, modified_file_path],
#             check=True,
#             capture_output=True,
#             text=True,
#         )
#     except subprocess.CalledProcessError as e:
#         raise
#     return modified_file_path


# if __name__ == "__main__":
#     import uvicorn

#     uvicorn.run(app, host="0.0.0.0", port=8000)









































from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse
import os
import shutil
import subprocess
from docx2pdf import convert

app = FastAPI()

UPLOAD_DIRECTORY = "/tmp/uploaded_files"
MODIFIED_DIRECTORY = "/tmp/modified_files"

# Ensure the directories exist
os.makedirs(UPLOAD_DIRECTORY, exist_ok=True)
os.makedirs(MODIFIED_DIRECTORY, exist_ok=True)


@app.post("/upload-pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    # Save the uploaded file
    file_location = os.path.join(UPLOAD_DIRECTORY, file.filename)
    with open(file_location, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # Process the file
    modified_file_location = await process_pdf(file_location)

    return FileResponse(
        modified_file_location,
        media_type="application/pdf",
        filename=f"modified_{file.filename}",
    )


async def process_pdf(file_path: str) -> str:
    # Ensure the directories exist
    os.makedirs(MODIFIED_DIRECTORY, exist_ok=True)

    # Determine file extension
    _, ext = os.path.splitext(file_path)

    if ext.lower() == ".pdf":
        # Directly process the PDF file with perfect.py
        modified_file_path = os.path.join(MODIFIED_DIRECTORY, f"modified_{os.path.basename(file_path)}")
        try:
            subprocess.run(["python3", "perfect.py", file_path, modified_file_path], check=True)
        except subprocess.CalledProcessError as e:
            raise
        return modified_file_path
    elif ext.lower() == ".docx":
        # Convert .docx to .pdf first
        base_name = os.path.basename(file_path)
        file_name, _ = os.path.splitext(base_name)
        pdf_file_path = os.path.join(MODIFIED_DIRECTORY, f"{file_name}.pdf")

        try:
            convert(file_path, pdf_file_path)
        except Exception as e:
            raise

        # Process the PDF file with perfect.py
        modified_file_path = os.path.join(MODIFIED_DIRECTORY, f"modified_{file_name}.pdf")

        try:
            subprocess.run(
                ["python3", "perfect.py", pdf_file_path, modified_file_path],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as e:
            raise
        return modified_file_path
    else:
        # print(f"Unsupported file type: {ext}")
        raise ValueError("Input file must be a .pdf or .docx file")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
















