# from docx import Document
# import fitz  # PyMuPDF

# def convert_docx_to_pdf(docx_path, pdf_path):
#     # Load the Word document
#     doc = Document(docx_path)
    
#     # Create a new PDF
#     pdf_document = fitz.open()
    
#     for para in doc.paragraphs:
#         # Create a new page for each paragraph
#         page = pdf_document.new_page()
        
#         # Add the paragraph text to the PDF page
#         text = para.text
#         page.insert_text((72, 72), text, fontsize=12)  # (72, 72) is the start position
        
#     # Save the PDF to the specified path
#     pdf_document.save(pdf_path)
#     pdf_document.close()

# if __name__ == "__main__":
#     # Path to the Word document
#     docx_path = r'Contract 5 - Unrevieweddd.docx'
    
#     # Path where the PDF will be saved
#     pdf_path = r'document.pdf'
    
#     # Convert the document
#     convert_docx_to_pdf(docx_path, pdf_path)

#     print(f"Conversion successful! PDF saved at: {pdf_path}")






# import os
# from docx import Document
# import win32com.client

# def convert_docx_to_pdf(docx_path, pdf_path):
#     try:
#         word = win32com.client.Dispatch("Word.Application")
#         doc = word.Documents.Open(docx_path)
#         doc.SaveAs(pdf_path, FileFormat=17)  # 17 corresponds to the PDF format
#         doc.Close()
#         word.Quit()
#         print(f"Successfully converted {docx_path} to {pdf_path}")
#     except Exception as e:
#         print(f"Error: {e}")

# # Example usage
# docx_path = "Contract 5 - Unrevieweddd.docx"
# pdf_path = "document111.pdf"

# convert_docx_to_pdf(docx_path, pdf_path)



# from docx2pdf import convert

# # Example usage
# docx_path = "Contract 5 - Unreviewed.docx"
# pdf_path = "document11111.pdf"

# # Convert .docx to .pdf
# convert(docx_path, pdf_path)

# print(f"Successfully converted {docx_path} to {pdf_path}")







# import pypandoc

# docx_path = "Contract 5 - Unreviewed.docx"
# pdf_path = "document11111.pdf"

# # Convert .docx to .pdf using pypandoc
# pypandoc.convert_file(docx_path, 'pdf', outputfile=pdf_path)

# print(f"Successfully converted {docx_path} to {pdf_path}")





# from docx2pdf import convert

# # Function to convert .docx to .pdf
# def convert_docx_to_pdf(docx_path, pdf_path):
#     try:
#         convert(docx_path, pdf_path)
#         print(f"Converted '{docx_path}' to '{pdf_path}'")
#     except Exception as e:
#         print(f"Error converting '{docx_path}' to '{pdf_path}': {str(e)}")

# # Example usage
# docx_path = 'Contract 5 - Unreviewed.docx'  # Replace with your .docx file path
# pdf_path = 'document.pdf'    # Replace with your desired .pdf file path
# convert_docx_to_pdf(docx_path, pdf_path)









# from docx import Document
# from reportlab.lib.pagesizes import letter
# from reportlab.pdfgen import canvas
# import os

# # Function to convert .docx to .pdf
# def convert_docx_to_pdf(docx_path, pdf_path):
#     # Load the .docx file
#     doc = Document(docx_path)
    
#     # Create a new PDF file
#     pdf_filename = os.path.splitext(os.path.basename(pdf_path))[0]
#     c = canvas.Canvas(pdf_path, pagesize=letter)
    
#     # Extract text from each paragraph in the document
#     for para in doc.paragraphs:
#         c.drawString(72, 720, para.text)  # Adjust coordinates as needed
#         c.showPage()  # Start a new page for each paragraph
    
#     # Save the PDF
#     c.save()
#     print(f"Converted '{docx_path}' to '{pdf_path}'")

# # Example usage
# docx_path = 'Contract 5 - Unreviewed.docx'  # Replace with your .docx file path
# pdf_path = 'document.pdf'    # Replace with your desired .pdf file path
# convert_docx_to_pdf(docx_path, pdf_path)








# from docx import Document
# from reportlab.lib.pagesizes import letter
# from reportlab.pdfgen import canvas
# import os

# # Function to convert .docx to .pdf
# def convert_docx_to_pdf(docx_path, pdf_path):
#     # Create a new PDF file
#     c = canvas.Canvas(pdf_path, pagesize=letter)
#     y = 720  # Initial y position for text
    
#     # Load the .docx file
#     doc = Document(docx_path)
    
#     # Extract text from each paragraph in the document
#     for para in doc.paragraphs:
#         # Write each paragraph to the PDF
#         c.drawString(72, y, para.text)  # Adjust x and y positions as needed
#         y -= 15  # Move to the next line
#         if y < 50:
#             c.showPage()  # Start a new page if text goes beyond the page height
#             y = 720  # Reset y position for new page
    
#     # Save the PDF
#     c.save()
#     print(f"Converted '{docx_path}' to '{pdf_path}'")

# # Example usage
# docx_path = 'Contract 5 - Unreviewed.docx'  # Replace with your .docx file path
# pdf_path = 'document.pdf'    # Replace with your desired .pdf file path
# convert_docx_to_pdf(docx_path, pdf_path)




# from docx2pdf import convert

# # Path to the Word document
# word_file = "Contract5.docx"

# # Convert the Word document to PDF
# convert(word_file)



from docx2pdf import convert
import fitz  # PyMuPDF library

# Path to the Word document
word_file = "Contract 5 - Unreviewed.docx"

# Convert the Word document to PDF
convert(word_file)

# Path to the converted PDF file
pdf_file = "Contract 5 - Unreviewed.pdf"

# Open the PDF file
pdf_document = fitz.open(pdf_file)

# Print width of each page
for page_num in range(len(pdf_document)):
    page = pdf_document.load_page(page_num)
    width = page.rect.width  # Get width of the page
    print(f"Width of page {page_num + 1}: {width} points")

# Close the PDF document
pdf_document.close()
