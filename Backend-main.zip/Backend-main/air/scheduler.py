

# # # from apscheduler.schedulers.background import BackgroundScheduler
# # # from apscheduler.triggers.interval import IntervalTrigger
# # # from sendgrid import SendGridAPIClient
# # # from sendgrid.helpers.mail import Mail
# # # from datetime import datetime
# # # import pytz
# # # import atexit


# # # def print_message():
# # #     now = datetime.now(pytz.timezone('UTC')).strftime("%Y-%m-%d %H:%M:%S")
# # #     print(f"Current time is: {now}")

# # # def send_email():
# # #     message = Mail(
# # #         from_email='sanyam.kumar@appicsoftwares.in',  # Replace with your email
# # #         to_emails='rohit.prajapat@appicsoftwares.in',  # Replace with recipient email
# # #         subject='Scheduled Email',
# # #         html_content='This is an automatically scheduled email sent every 1 minutes.'
# # #     )
# # #     try:
# # #         sg = SendGridAPIClient('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')  # Replace with your SendGrid API key
# # #         response = sg.send(message)
# # #         print(f"Email sent with status code: {response.status_code}")
# # #     except Exception as e:
# # #         print(f"Failed to send email. Error: {e}")

# # # scheduler = BackgroundScheduler()
# # # scheduler_started = False  # Flag to check if the scheduler has started


# # # # Add jobs with appropriate triggers
# # # scheduler.add_job(print_message, trigger=IntervalTrigger(seconds=1))
# # # scheduler.add_job(send_email, trigger=IntervalTrigger(seconds=1))
# # # scheduler.start()

# # # atexit.register(lambda: scheduler.shutdown())

# # # # air/scheduler.py

# # # from apscheduler.schedulers.background import BackgroundScheduler
# # # from apscheduler.triggers.interval import IntervalTrigger
# # # from datetime import datetime
# # # import pytz

# # # def print_message():
# # #     now = datetime.now(pytz.timezone('UTC')).strftime("%Y-%m-%d %H:%M:%S")
# # #     print(f"Current time is: {now}")

# # # scheduler = BackgroundScheduler()
# # # scheduler.add_job(print_message, trigger=IntervalTrigger(seconds=2))
# # # scheduler.start()

# # # # Shut down the scheduler when exiting the app
# # # import atexit
# # # atexit.register(lambda: scheduler.shutdown())


# # # +++++++++++++++++++++++++++++++++++++++++


# # # air/scheduler.py

# # from apscheduler.schedulers.background import BackgroundScheduler
# # from apscheduler.triggers.interval import IntervalTrigger
# # from sendgrid import SendGridAPIClient
# # from sendgrid.helpers.mail import Mail
# # from datetime import datetime
# # import pytz 
# # from .serializers import *
# # from .serializers import JourneySerializer


# # def print_message():
# #     now = datetime.now(pytz.timezone('UTC')).strftime("%Y-%m-%d %H:%M:%S")
# #     print(f"Current time is: {now}")

# # def send_email():
# #     filtered_journeys = Journey.objects.filter(price__lt=63524)

# #     # Serialize the data
# #     serializer = JourneySerializer(filtered_journeys, many=True)
# #     serialized_data = serializer.data

# #     html_content = '<h1>Scheduled Email</h1>'
# #     html_content += '<p>This is an automatically scheduled email sent every 1 minute.</p>'
# #     html_content += '<ul>'
# #     for journey in serialized_data:
# #         html_content += f"<li>{journey['orig_city']} to {journey['dest_city']} - Price: {journey['price']}</li>"
# #     html_content += '</ul>'


    

# #     # Format the serialized data as HTML content
   


# #     message = Mail(
# #         from_email='info@aaseya.com',  # Replace with your email
# #         to_emails='rohit.prajapat@appicsoftwares.in',  # Replace with recipient email
# #         subject='Scheduled Email',
# #         # html_content='This is an automatically scheduled email sent every 1 minutes.'
# #         html_content=html_content

        

# #     )
# #     try:
# #         sg = SendGridAPIClient('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')  # Replace with your SendGrid API key
# #         response = sg.send(message)
# #         print(f"Email sent with status code: {response.status_code}")
# #     except Exception as e:
# #         print(f"Failed to send email. Error: {e}")

# # scheduler = BackgroundScheduler()

# # # Clear existing jobs before adding new ones
# # # scheduler.remove_all_jobs()

# # # Add jobs with appropriate triggers
# # scheduler.add_job(print_message, trigger=IntervalTrigger(seconds=1))
# # scheduler.add_job(send_email, trigger=IntervalTrigger(seconds=1))
# # scheduler.start()

# # import atexit
# # atexit.register(lambda: scheduler.shutdown())






# # air/scheduler.py

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from datetime import datetime
from .serializers import JourneySerializer
from .models import Journey

import pytz

def print_message():
    now = datetime.now(pytz.timezone('UTC')).strftime("%Y-%m-%d %H:%M:%S")
    print(f"Current time is: {now}")

def send_email():

    filtered_journeys = Journey.objects.filter(price__lt=2400000)
    

    # print(filtered_journeys,"filtered_journeys")

    # Serialize the data
    serializer = JourneySerializer(filtered_journeys, many=True)
    serialized_data = serializer.data
    # print(serialized_data,"serialized_data")
    # Format the serialized data as HTML content
    html_content = '<h1>Scheduled Email</h1>'
    html_content += '<p>This is an automatically scheduled email sent every 1 minute.</p>'
    html_content += '<ul>'
    for journey in serialized_data:
        html_content += f"<li>{journey['orig'][0]} to {journey['dest'][0]}({journey['airline']})-Scheduled Departure Time: {journey['orig_time'].split('T')[0]} {journey['orig_time'].split('T')[1].replace('Z', '')} - Price: ${journey['price']}</li>"
    html_content += '</ul>'

    message = Mail(
        from_email='mohit.appic@gmail.com',  # Replace with your email
        to_emails='sanyamkukreja1233@gmail.com',  # Replace with recipient email
        subject='Scheduled Email',
        html_content=html_content
    )
    try:
        sg = SendGridAPIClient('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')  # Replace with your SendGrid API key
        response = sg.send(message)
        print(f"Email sent with status code: {response.status_code}")
    except Exception as e:
        print(f"Failed to send email. Error: {e}")

send_email()    
# scheduler = BackgroundScheduler()

# Clear existing jobs before adding new ones
# scheduler.remove_all_jobs()

# Add job with appropriate trigger
# scheduler.add_job(send_email, trigger=IntervalTrigger(seconds=15))

# scheduler.add_job(print_message, trigger=IntervalTrigger(seconds=1))

# scheduler.start()

# import atexit
# atexit.register(lambda: scheduler.shutdown())