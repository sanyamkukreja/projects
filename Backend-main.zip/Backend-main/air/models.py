from django.db import models
from django.utils import timezone




class Journey(models.Model):
    price = models.IntegerField(default='')
    orig = models.JSONField(default=dict)
    orig_time = models.DateTimeField(default=timezone.now) 
    dest = models.JSONField(default=dict)
    dest_time = models.DateTimeField(default=timezone.now)
    class_name = models.CharField(max_length=50,default="")
    duration = models.CharField(max_length=20,default="")
    airline = models.CharField(max_length=100,default="")
    stop_flights = models.CharField(max_length=50,default="")
    stopover_info = models.JSONField(default=dict)
    airport_code = models.CharField(max_length=10,default="")

    def __str__(self):
        return f"{self.id}"

class Journeyinfo(models.Model):
    price = models.DecimalField(max_digits=10, decimal_places=2)
    start_date = models.DateField()
    end_date = models.DateField()
    origin=models.CharField(max_length=20,default='')
    dest=models.CharField(max_length=20,default='')
    user=models.CharField(max_length=50,default='')
 

    def __str__(self):
        return f"Journey #{self.id}"

    
class ContactUs(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField()
    phone=models.CharField(max_length=20,blank=True)
    message=models.TextField()
    
   