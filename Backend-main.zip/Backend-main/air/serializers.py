from rest_framework import serializers
from .models import *

class JourneySerializer(serializers.ModelSerializer):
    class Meta:
        model = Journey
        # fields = ['id', 'origin', 'destination', 'created_at']
        fields = '__all__'


class JourneyInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Journeyinfo
        fields = ['price', 'start_date', 'end_date','origin','dest','user']
    

class ContactUsSer(serializers.ModelSerializer):
    class Meta:
        model=ContactUs
        fields='__all__'
     