document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contactForm');
    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent default form submission

        // Collect form data
        const formData = {
            'name': document.getElementById('name').value,
            'email': document.getElementById('email').value,
            'phone': document.getElementById('phone').value,
            'message': document.getElementById('message').value,
        };

        // Get CSRF token from the hidden input field
        const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

        // Send fetch POST request to Django API endpoint
        fetch('http://localhost:8000/api/contacts/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken
            },
            body: JSON.stringify(formData)
        })
            .then(response => response.json())
            .then(data => {
                // Handle success response (optional)
                console.log('Success:', data);
                alert('Message sent successfully!');
                // Optionally, clear the form fields after successful submission
                document.getElementById('name').value = '';
                document.getElementById('email').value = '';
                document.getElementById('phone').value = '';
                document.getElementById('message').value = '';
            })
            .catch(error => {
                // Handle error response (optional)
                console.error('Error:', error);
                alert('Error sending message.');
            });
    });
});
