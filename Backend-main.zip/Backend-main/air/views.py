from django.shortcuts import render,redirect
import airportsdata
from .models import *
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import viewsets
from .serializers import *
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import HttpResponse
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from login_signup.utils import send_email,send_email_to_client
from datetime import datetime
from django.utils import timezone
# Create your views here.
from login_signup.custom_authentication import CustomJWTAuthentication
from rest_framework.permissions import IsAuthenticated



class JourneyCreateview(viewsets.ModelViewSet):
    
    queryset = Journey.objects.all()
    serializer_class = JourneySerializer

    def list(self, request, *args, **kwargs): 
        filtered_journeys = self.queryset.filter(price__gt=0)

        # Serialize the filtered journeys
        serializer = self.serializer_class(filtered_journeys, many=True)


        return Response(serializer.data, status=status.HTTP_200_OK)
    
 



class JourneyinfoViewSet(viewsets.ModelViewSet):
    queryset = Journeyinfo.objects.all()
    serializer_class = JourneyInfoSerializer
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = request.user.email
        serializer.validated_data['user']=request.user
        self.perform_create(serializer)
        journey_info = serializer.instance
        filtered_journeys = self.get_filtered_journeys(journey_info)
        journey_serializer = JourneySerializer(filtered_journeys, many=True)
        serialized_data = serializer.data
        journey_serialized_data = journey_serializer.data
        # print(serialized_data,"serialized_data")
        # Format the serialized data as HTML content
        html_content = '<h1>Scheduled Email</h1>'
        html_content += '<p>This is an automatically scheduled email sent every 1 minute.</p>'
        html_content += '<ul>'
        for journey in journey_serialized_data:
            html_content += f"<li>{journey['orig'][0]} to {journey['dest'][0]}({journey['airline']})-Scheduled Departure Time: {journey['orig_time'].split('T')[0]} {journey['orig_time'].split('T')[1].replace('Z', '')} - Price: ${journey['price']}</li>"
        html_content += '</ul>'
        data = {
            'subject':'Scheduled Email',
            'body':html_content,
            'to_email':email  
        }
        
        try:
            send_email(data)
        except Exception as e:
            print(f"\n  ***** {e} ***** \n")

            return Response({'error':f"\n  ***** {e} ***** \n"})
        
        # message = Mail(
        #     from_email='mohit.appic@gmail.com',  # Replace with your email
        #     to_emails='sachinappic143@gmail.com',  # Replace with recipient email
        #     subject='Scheduled Email',
        #     html_content=html_content
        # )
        # try:
        #     sg = SendGridAPIClient('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')  # Replace with your SendGrid API key
        #     response = sg.send(message)
        #     print(f"Email sent with status code: {response.status_code}")
        # except Exception as e:
        #     print(f"Failed to send email. Error: {e}")
        headers = self.get_success_headers(serializer.data)
        return Response(journey_serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def get_filtered_journeys(self, journey_info):
        orig = journey_info.origin  # Assuming the first element is the IATA code
        dest = journey_info.dest  # Assuming the first element is the IATA code
        
        start_date = journey_info.start_date
        end_date = journey_info.end_date
        
        if isinstance(start_date, datetime):
            start_date = start_date.date()
        if isinstance(end_date, datetime):
            end_date = end_date.date()

        # Debugging information
        print(f"Filtering journeys with origin: {orig}, destination: {dest}, price < {journey_info.price}, start_date: {start_date}, end_date: {end_date}")

        results = Journey.objects.filter(
            price__lt=journey_info.price,
            orig_time__date__gte=start_date,
            orig_time__date__lte=end_date,
            orig__0=orig,
            dest__0=dest,
        )
        
        # Debugging information
        print(f"Filtered results count: {results.count()}")
        # for result in results:
            # print(f"Result: {result.orig} to {result.dest} at {result.orig_time} for price {result.price}")
        
        return results
   


class ContactCreateView(viewsets.ModelViewSet):
    queryset = ContactUs.objects.all()
    serializer_class = ContactUsSer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response({'message': 'Thanks for reaching out! Lipton Adventures will be in touch with you soon.','data':serializer.data}, status=status.HTTP_201_CREATED, headers=headers)
