# from django.apps import AppConfig


# class AirConfig(AppConfig):
#     default_auto_field = 'django.db.models.BigAutoField'
#     name = 'air'

#     def ready(self):
#         from .scheduler import scheduler
#         import threading
#         scheduler_thread = threading.Thread(target=scheduler.start)
#         print(scheduler_thread,"ssssssssss")
#         scheduler_thread.start()
#          # This ensures that the cron job is imported
