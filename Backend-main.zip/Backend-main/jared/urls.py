"""
URL configuration for jared project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from air import views
from rest_framework.routers import DefaultRouter
from air.views import *
from django.views.generic import TemplateView
from rest_framework import routers
from login_signup.views import *
router = routers.DefaultRouter()
router.register(r'contact_us',ContactCreateView, basename='FAQ-VIEW')
router.register(r'journey',JourneyCreateview,basename='journey')
router.register(r'journeyinfos', JourneyinfoViewSet, basename='journeyinfo')

router.register(r'login_signup/Admin-register',AdminRegisterviewset, basename = 'Admin-register')
router.register(r'login_signup/admin_login', AdminLoginViewSet, basename='admin-login')
router.register(r'login_signup/admin-otp-verify', AdminPasswordResetViewSet, basename = 'admin-otp-verify')

router.register(r'login_signup/user-register',UserRegisterViewSet, basename='user-register')
router.register(r'login_signup/user-otp-verify',UserOTPVerifyViewSet, basename='user-otp-verify')
router.register(r'login_signup/user-login',UserLoginViewSet, basename='user-login')
router.register(r'login_signup/user-otp-verify-password-reset', UserPasswordResetOTPVerifyViewSet, basename = 'user-otp-verify-password-reset')
router.register(r'login_signup/user-password-reset', UserPasswordResetViewSet, basename = 'user-password-reset')
router.register(r'login_signup/user-profile', UserProfile, basename = 'user-profile-view')

# router for providing permissions
router.register(r'login_signup/User-permission',UserPermissionViewSet, basename='user-permission')
router.register(r'login_signup/admin/groups',GroupCreateView,basename='create-group')
# Permissions List Router ############################3
router.register(r'login_signup/permission-list',PermissonsRetrieveViewSet, basename = 'permission-list')

router.register(r'login_signup/ResendOtp',ResendOTPRequestViewSet,basename='resend-otp')
router.register(r'login_signup/ChangePassword',ChangePasswordViewSet,basename='change-password')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('contact/', TemplateView.as_view(template_name='index.html'), name='contact-form'),
    path('success/', TemplateView.as_view(template_name='success.html'), name='contact-form'),
    path('api/', include(router.urls)),
]

