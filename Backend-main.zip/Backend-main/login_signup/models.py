from django.db import models

from django.contrib.auth.models import AbstractUser
# from django.utils.translation import ugettext_lazy as _
from .managers import *


from django.utils import timezone
from django.contrib.auth.hashers import make_password


# Create your models here.

class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True) 
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    objects = CustomUserManager()
    full_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20,blank=True)
    home_airport=models.CharField(max_length=100,blank=True)
    otp = models.IntegerField(null = True, blank = True)
    otp_verified = models.BooleanField(default = False, null = True)


  
class UserLogin(models.Model):
    email = models.EmailField(max_length=255, unique=True)
    password = models.CharField(max_length=128)
    remember_me = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.pk or UserLogin.objects.get(pk=self.pk).password != self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.email
    




