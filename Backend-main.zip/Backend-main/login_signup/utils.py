from django.core.mail import EmailMessage
import os
from django.core.mail import send_mail
# Import for OTP
# from twilio.rest import Client  # Import the Twilio Client if using Twilio
import string
import random
from django.conf import settings
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail



# print("\n**** send_email_to_client ******")
# def send_email_to_client(data):
#     # subject = "Testing of Mail"
#     subject = data['subject']
#     # message = "This is test message"
#     message = data['body']
#     # from_email = "adityabansal.2cse23@jecrc.ac.in"
#     from_email = settings.DEFAULT_FROM_EMAIL
#     # recipient_list = ["aditya.bansal@appicsoftwares.in"]
#     recipient_list = [data['to_email']]
#     send_mail(subject, message, from_email, recipient_list)



def send_email_to_client(data):
    message = Mail(
        from_email=settings.DEFAULT_FROM_EMAIL,
        to_emails=data['to_email'],
        subject=data['subject'],
        plain_text_content=data['body']
    )

    try:
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        response = sg.send(message)
        return {
            'status': 'success',
            'status_code': response.status_code,
            'body': response.body,
            'headers': response.headers
        }
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e)
        }
    

def send_email(data):
    message = Mail(
        from_email=settings.DEFAULT_FROM_EMAIL,
        to_emails=data['to_email'],
        subject=data['subject'],
        html_content=data['body']
    )

    try:
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        response = sg.send(message)
        return {
            'status': 'success',
            'status_code': response.status_code,
            'body': response.body,
            'headers': response.headers
        }
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e)
        }
    

# print("\n**** Util class ******")
# class Util:
#     # print("\n***** static method ******")
#     @staticmethod
#     def send_email(data):
#         # print("\n****** data inside send_email **** : ",data)
#         # print("\n****** data inside send_email **** : ",os.environ)
#         print("\n****** settings.DEFAULT_FROM_EMAIL **** : ",settings.DEFAULT_FROM_EMAIL,"\n ******* \n")
#         email = EmailMessage(
#             subject=data['subject'],
#             body=data['body'],
#             from_email=settings.DEFAULT_FROM_EMAIL,
#             to=[data['to_email']]
#             # to=['mohit.appic@gmail.com']
#         )
#         # print("\n***** email : ",email)
#         # print("\n email.subject : ",email.subject,"\n email.body : ",email.body,"\n email.from_email : ",email.from_email,"\n email.to : ",email.to)
#         # send_mail(email.subject, email.body, email.from_email, email.to)
#         # # print("\n @@@@@ \n email.send : ",email.send(),"\n @@@@@@ \n")
#         email.send()


# def 

# OTP verification which comes on mobile  number
def generate_otp(length=4):
    characters = string.digits
    otp = ''.join(random.choice(characters) for _ in range(length))
    # # print("\n ##### \n type of utils otp : ",type(otp),"\n ###### \n")
    # # print("\n ##### \n utils otp : ",otp,"\n ###### \n")
    return otp

# https://console.twilio.com/

# def send_otp_phone(phone_number, otp):
#     # account_sid = 'your_account_sid'  # Replace with your Twilio account SID
#     account_sid = 'AC787e1b6fa64dd02b03e7dc7f47c717d1'  # Replace with your Twilio account SID
#     # auth_token = 'your_auth_token'  # Replace with your Twilio auth token
#     auth_token = 'a38df6ba17377dbfb3b9be9684ec1d0a'  # Replace with your Twilio auth token
#     # twilio_phone_number = 'your_twilio_phone_number'  # Replace with your Twilio phone number
#     twilio_phone_number = '+14247329884'  # Replace with your Twilio phone number

#     client = Client(account_sid, auth_token)  
#     message = client.messages.create(
#         body=f'Your OTP is: {otp}',
#         from_=twilio_phone_number, 
#         to=phone_number   
#     )



