from django.shortcuts import render
from rest_framework import viewsets,status
from django.shortcuts import get_object_or_404

from .models import *
from .serializers import *
from rest_framework.response import Response
from .utils import * 
from sendgrid.helpers.mail import Mail
from sendgrid import SendGridAPIClient
import imghdr
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.response import Response
from rest_framework.decorators import action

from django.contrib import messages
from django.contrib.auth.hashers import check_password, make_password
from django.shortcuts import render, redirect
from rest_framework import viewsets, status
from rest_framework.permissions import AllowAny

from .custom_authentication import CustomJWTAuthentication 

from rest_framework_simplejwt.tokens import RefreshToken

from django.contrib.auth.models import Permission





def get_tokens_for_user(user):
    # # print("\n ***** get_token_for_user ***** : \n")
    # # print("\n user \n ",user)
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class GroupCreateView(viewsets.ModelViewSet):

    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes=[AllowAny]



class UserPermissionViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    # queryset = Permission.objects.all()
    serializer_class = UserPermissionSer

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')

        serializer = UserProfileSer(queryset, many = True)

        return Response(serializer.data, status=status.HTTP_200_OK)
        

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data = request.data)

        serializer.is_valid(raise_exception = True)

        serializer.save()

        return Response({'msg':'Permissions updated successfully'},status=status.HTTP_200_OK)


class AdminRegisterviewset(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_superuser=True)
    serializer_class = AdminRegisterser

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
    
        admin_user = User.objects.create_superuser(**serializer.validated_data)
        # else:
        #     admin_user = AdminUser.objects.create_user(**serializer.validated_data)
        return Response({'msg': 'Admin user created successfully'}, status=status.HTTP_201_CREATED)
     
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        serializer = self.get_serializer(queryset, many=True)
        return Response({'msg': 'Admin list fetched successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
    
    
class AdminLoginViewSet(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_superuser=True)
    serializer_class = AdminLoginSer
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)
    
        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')

        admin_user = User.objects.filter(email = email).first()

        if admin_user == None:
            return Response({'msg':'Admin user with this email id not exist'},status=status.HTTP_404_NOT_FOUND)
        
        print("\n **** admin_user.password **** \n",admin_user.password)
        print("\n **** password **** \n",password)

        if not check_password(password,admin_user.password):
            return Response({'msg':'Incorrect password'},status=status.HTTP_400_BAD_REQUEST)

        admin_user_obj = User.objects.filter(email = email).first()

        admin_ser = UserProfileSer(admin_user_obj)

        token = get_tokens_for_user(admin_user_obj)

        return Response({'msg':'Login successful', 'token':token, 'data':admin_ser.data},status=status.HTTP_200_OK) 

    def list(self, request, *args, **kwargs):
        queryset = User.objects.filter(is_superuser=True)

        serializer = self.serializer_class(queryset, many=True)

        return Response(serializer.data,status=status.HTTP_200_OK)


class AdminPasswordResetViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = AdminPasswordResetSer
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')
        otp = int(serializer.validated_data.get('otp'))
        
        admin_user = User.objects.get(email = email)
        print(type(otp),"dfghjkl")
        # otp_obj = GenerateOTP.objects.filter(admin_user = admin_user, otp=otp).first()
        stored_otp = admin_user.otp      
        print(type(stored_otp),"igfxz")
        if stored_otp == otp: 
            admin_user.set_password(password)
            # admin_user.password = password
            admin_user.save()
            return Response({'msg':f'Password reset successfully '},status=status.HTTP_200_OK)
        else:
            return Response({'msg':'Incorrect OTP'},status=status.HTTP_400_BAD_REQUEST)
        

   


# ***** User
class UserRegisterViewSet(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_superuser=False)
    serializer_class = UserRegisterSer

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.validated_data.get('email')
        otp = generate_otp()

        user = serializer.save()
        user.otp = otp
        # vendor.set_password(vendor.password)
        user.is_active = False
        user.save()
        body = 'OTP is : '+ otp
        data = {
            'subject':'Email OTP for Registration',
            'body':body,
            'to_email':email  
        }
        
        try:
            send_email_to_client(data)
        except Exception as e:
            print(f"\n  ***** {e} ***** \n")

            return Response({'error':f"\n  ***** {e} ***** \n"})
        return Response({'msg':'OTP sent successfully'},status=status.HTTP_200_OK)
    
        # return Response({'msg':'User created successfully'},status=status.HTTP_200_OK)
    
    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)     
        serializer.save()
        return Response({'msg':'Your profile updated successfully','user_data':serializer.data},status=status.HTTP_200_OK)
    
class UserOTPVerifyViewSet(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_superuser=False)
    serializer_class = UserRegisterOTPVerifySer

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.validated_data.get('email')
        otp = serializer.validated_data.get('otp')

        user = User.objects.filter(email = email).first()

        if user == None:
            return Response({'error':f'User with this email does not exist'},status=status.HTTP_404_NOT_FOUND)

        if user.otp != otp:

            return Response({'error':'Invalid OTP'},status=status.HTTP_400_BAD_REQUEST)
        
        #vendor_user.is_active=True
        vendor = UserProfileSer(user)
        stored_otp = user.otp
        if stored_otp == otp:   
            # vendor_user.set_password(password)
            user.otp_verified = True
            user.save()
        # vendor_user.save()

        return Response({'msg':'OTP verified successfully','data':vendor.data},status=status.HTTP_200_OK)

   
    

class UserLoginViewSet(viewsets.ViewSet):
    queryset = User.objects.filter(is_superuser=False)
    serializer_class = UserLoginSer

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context
    
    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data,context={'request': request})
        serializer.is_valid(raise_exception=True)
    
        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')

        user = User.objects.filter(email = email).first()
        # document_data = UserProfileSer(vendor_user,context={'request':request})
        if user == None:
            return Response({'msg':'User with this email id not exist'},status=status.HTTP_404_NOT_FOUND)
        
        
        if not check_password(password,user.password):
            return Response({'msg':'Incorrect password'},status=status.HTTP_400_BAD_REQUEST)
        
        if user.otp_verified == '0':
            return Response({'msg': 'Profile not verified'}, status=status.HTTP_400_BAD_REQUEST)
        
        user_obj = User.objects.filter(email = email).first()

        user_ser = UserProfileSer(user_obj,context={'request':request})

        # print(vendor_user_obj,"ooooooooooooooooooooo")
        token = get_tokens_for_user(user_obj)

        return Response({'msg':'Login successful','token':token, 'data':user_ser.data},status=status.HTTP_200_OK) 


class UserPasswordResetOTPVerifyViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = UserRegisterOTPVerifySer
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        otp = int(serializer.validated_data.get('otp'))

        vendor_user = User.objects.get(email = email)
        # otp_obj = GenerateOTP.objects.filter(admin_user = admin_user, otp=otp).first()
        stored_otp = vendor_user.otp

        if stored_otp == otp:   
            # vendor_user.set_password(password)
            vendor_user.otp_verified = True
            vendor_user.save()
            return Response({'msg':f' OTP verified successfully'},status=status.HTTP_200_OK)
        else:
            return Response({'msg':'Incorrect OTP'},status=status.HTTP_400_BAD_REQUEST)


class UserPasswordResetViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserPasswordResetSer

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')
        confirm_password = serializer.validated_data.get('confirm_password')

        vendor_obj = User.objects.filter(email = email).first()

        if vendor_obj.otp_verified == False:
            return Response({'error':'Incorrect OTP'},status=status.HTTP_400_BAD_REQUEST)
        
        vendor_obj.set_password(password)
  
        vendor_obj.save()

        return Response({'msg':f'Password reset successfully'},status=status.HTTP_200_OK)
    

    
class UserProfile(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserProfileSer
    # authentication_classes = [CustomJWTAuthentication]

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        serializer = self.get_serializer(queryset, many=True) 
        return Response({'msg': 'User profiles fetched successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
    

class PermissonsRetrieveViewSet(viewsets.ModelViewSet): 
    queryset = Permission.objects.all()  
    serializer_class = PermissionSerializer 


class ResendOTPRequestViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserPasswordResetRequestSer
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')

        try:
            # Fetch the user by email
            user = User.objects.filter(email = email).first()

            # Generate OTP
            otp = generate_otp()
            user.otp = otp
            user.save()

            # Send OTP via Email
            body = f'Your OTP is: {otp}'

            data = {
                'subject': 'Email OTP for password reset',
                'body': body,
                'to_email': email
            }

            send_email_to_client(data)

            return Response({'msg': 'OTP resend successfully '}, status=status.HTTP_200_OK)
        except ObjectDoesNotExist:
            return Response({'error': 'User with this email does not exist.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
class ChangePasswordViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = ChangePasswordSer
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        old_password = serializer.validated_data.get('old_password')
        password = serializer.validated_data.get('password')
        confirm_password = serializer.validated_data.get('confirm_password')

        user = User.objects.filter(email = email).first()
        if not check_password(old_password,user.password):
            return Response({'msg':'The old password you entered is incorrect. Please try again.'},status=status.HTTP_400_BAD_REQUEST)
        else:
            if password!=confirm_password:
                return Response({'msg':'Password and ConfirmPassword should be same. Please try again.'},status=status.HTTP_400_BAD_REQUEST)
            else:
                user.set_password(password)
                user.save()
                return Response({'msg':f'Password Changed Successfully'}, status = status.HTTP_200_OK)
                      

    
