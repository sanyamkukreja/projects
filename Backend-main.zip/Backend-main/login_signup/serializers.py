from rest_framework import serializers
from .models import *
from django.contrib.auth.models import Group, Permission
import random
import string
from django.core.mail import send_mail

from .utils import send_email_to_client


# ****** Admin User

class AdminRegisterser(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'password'] 

    def create(self, validated_data):
        return User.objects.create_superuser(**validated_data)


class AdminLoginSer(serializers.ModelSerializer):
    email = serializers.EmailField()
    class Meta:
        model = User
        fields = ['id', 'email', 'password']  


class AdminPasswordResetSer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()
    otp = serializers.CharField(max_length = 4)


class UserPermissionSer(serializers.Serializer):
    user = serializers.PrimaryKeyRelatedField(queryset = User.objects.all())
    permission = serializers.PrimaryKeyRelatedField(queryset = Permission.objects.all(), many = True)

    def create(self, validated_data):
        user = validated_data['user']
        permissions = validated_data['permission']

        # user_obj = User.objects.filter(id = user) 
        
        # Add the permissions to the user
        user.user_permissions.set(permissions)
        # user_obj.user_permissions.set(permissions)

        return user


class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = ['id', 'name', 'codename']


class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ['id', 'name','permissions']

# ***** Vendor
class UserRegisterSer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True)
    password2 = serializers.CharField(write_only=True, required=True)
    
    class Meta:
        model = User
        fields = ['id', 'email', 'full_name', 'phone', 'password', 'password2','home_airport']
    
    def validate(self, attrs):
        password = attrs.get('password')
        password2 = attrs.get('password2')

        if password or password2:  
            if password != password2:
                raise serializers.ValidationError({"password": "Password fields didn't match."})
        attrs.pop('password2', None)
        return attrs
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = User(**validated_data)
        if password:
            user.set_password(password)
        user.save()
        return user
    def to_representation(self, instance):
        representation = super().to_representation(instance)

        representation['otp'] = instance.otp

        return representation
    

class UserRegisterOTPVerifySer(serializers.ModelSerializer):
    email = serializers.EmailField()
    class Meta:
        model = User
        fields = ['id', 'email', 'otp']
class UserPasswordResetRequestSer(serializers.ModelSerializer): 
    email = serializers.EmailField()
    class Meta:
        model = User
        fields = ['id','email']  

    def validate_email(self, value):
        if not User.objects.filter(email = value).exists():
            raise serializers.ValidationError('No user is associated with this email')
        return value



class UserPasswordResetSer(serializers.ModelSerializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only = True, required = True)
    confirm_password = serializers.CharField(write_only = True, required = True)

    
    class Meta:
        model = User
        fields = ['id', 'email', 'password', 'confirm_password']

    def validate(self, attrs):
        if attrs['password'] != attrs['confirm_password']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        attrs.pop('confirm_password')
        return attrs

class UserLoginSer(serializers.ModelSerializer):
    
    email = serializers.EmailField()
    class Meta:
        model=User
        fields = ['id', 'email','password']
    
    
    # def create(self, validated_data):
    #     # Hash the password before saving
    #     password = validated_data.pop('password')
    #     validated_data['password'] = make_password(password)
    #     return super().create(validated_data)

    # def update(self, instance, validated_data):
    #     # Hash the password before saving
    #     if 'password' in validated_data:
    #         password = validated_data.pop('password')
    #         validated_data['password'] = make_password(password)
    #     return super().update(instance, validated_data)
    

class UserProfileSer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__' 


# class UserCreateSerializer(serializers.ModelSerializer): 

#     class Meta:
#         model = User
#         fields = ['is_active', 'is_staff', 'full_name', 'email', 'phone', 'is_vendor', 'address', 'is_buyer','apartment_number', 'street_name', 'city', 'state', 'zip_code','shop_name']

#     def create(self, validated_data):
#         is_vendor = validated_data.get('is_vendor', False)
#         is_buyer = validated_data.get('is_buyer', False)  
        
#         if is_vendor:
#             validated_data['is_active'] = True
#             validated_data['is_staff'] = True
#             validated_data['is_vendor'] = True
#             validated_data['otp_verified'] = True
#         elif is_buyer:
#             validated_data['is_active'] = True
#             validated_data['is_buyer'] = True
#             validated_data['otp_verified'] = True

#         # Generate a random password
#         password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
#         print(password,"ppppppp")
#         # Set and hash the password
#         user = User(**validated_data)
#         user.set_password(password)
#         user.save()

#         body = 'Password is : '+ password

#         data = {
#             'subject':'Email OTP for Registration',
#             'body':body,
#             'to_email':user.email 
#         }
        
#         try:
#             send_email_to_client(data)
#         except Exception as e:
#             print(f"\n  ***** {e} ***** \n")

    
#         return user


class ChangePasswordSer(serializers.Serializer):
    email = serializers.EmailField()
    old_password = serializers.CharField(max_length = 128)
    password=serializers.CharField(max_length=128)
    confirm_password=serializers.CharField(max_length=128)

