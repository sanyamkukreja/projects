from django.db import models
from product.models import Product
from login_signup.models import User
# Create your models here.

class FAQ(models.Model):
    TYPE_CHOICES = [
        ('buyer', 'Buyer'),
        ('seller', 'Seller'),
        ('both', 'Both'),
    ]
    question = models.CharField(max_length=255)
    answer = models.TextField()
    type = models.CharField(max_length=6, choices=TYPE_CHOICES, default='both')


    def __str__(self):
        return self.question  
    


class Report(models.Model):

    
    STATUS = [
        ('pending', 'Pending'),
        ('resolved', 'Resolved'),
        ('revert', 'Revert'), 
    ]
    API_TYPES = (
        ('report', 'Report'),
        ('help', 'Help'),
    )

    USER_TYPES = (
        ('seller', 'Seller'),
        ('buyer', 'Buyer'),
    )


    buyer = models.ForeignKey(User, on_delete=models.CASCADE,related_name='buyer_reports' , blank=True,null=True, default='')
    seller = models.ForeignKey(User,related_name='seller_reports', on_delete=models.CASCADE,blank=True,null=True, default='')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, blank=True,null=True, default='')
    subject = models.CharField(max_length=255,blank=True,null=True)
    report_list=models.JSONField(default=list,blank=True,null=True) 
    description = models.TextField(null=True, blank=True,default='')
    status = models.CharField(max_length=10, choices=STATUS, default='pending')
    api_type = models.CharField(max_length=10, choices=API_TYPES,default='')
    user_type = models.CharField(max_length=10, choices=USER_TYPES,default='')

    def __str__(self):
        return f"Report  {self.id}"
    
