from django.shortcuts import render
from rest_framework import viewsets,status
from .models import *
from .serializers import *
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from login_signup.custom_authentication import CustomJWTAuthentication
from rest_framework.views import APIView
from product.serializers import ProductSer
# from rest_framework.pagination import PageNumberPagination
# from suscription.custom_pagination import CustomPagination
class FAQViewSet(viewsets.ModelViewSet):
    queryset = FAQ.objects.all()
    serializer_class = FAQSerializer
    # pagination_class = CustomPagination
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        if not queryset.exists():
            return Response({
                'message': 'No FAQs found',
                'data': []
            }, status=status.HTTP_200_OK)
        
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'status': 'success',
            'message': 'FAQs retrieved successfully',
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
        except FAQ.DoesNotExist:
            return Response({
                'status': 'error',
                'message': 'FAQ not found',
                'data': None
            }, status=status.HTTP_404_NOT_FOUND)
        
        serializer = self.get_serializer(instance)
        return Response({
            'status': 'success',
            'message': 'FAQ retrieved successfully',
            'data': serializer.data
        }, status=status.HTTP_200_OK)


class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAuthenticated]
    # pagination_class = CustomPagination

    def get_serializer_class(self):
        if self.action == 'list':
            return ListReportSerializer
        return super().get_serializer_class()

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response({'msg':'reports fetched successfully','data':serializer.data},status=status.HTTP_200_OK)
    
    def retrieve(self, request, pk=None):
        if not pk:
            return Response({'error': 'Product ID is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response({'error': 'Product not found'}, status=status.HTTP_404_NOT_FOUND)

        reports = Report.objects.filter(product=product).order_by('-id')
        serializer = ReportSerializer(reports, many=True)

        product_serializer = ProductSdetailserializer(product)

        # Construct the response data
        response_data = {
            'product': product_serializer.data,
            'reports': serializer.data

        } 
        return Response(response_data, status=status.HTTP_200_OK) 
class ProductReportViewSet(viewsets.ViewSet):
    def list(self, request):
        product_id = request.query_params.get('product_id')
        
        if product_id:
            products = Product.objects.filter(id=product_id)
        else:
            products = Product.objects.all()
        response_data = []
        
        for product in products:
            reports = Report.objects.filter(product=product).order_by('-id')
            if reports.exists():
                report_serializer = ListReportSerializer(reports, many=True)
                product_serializer = ProductSer(product,context={'request':request})
            # report_serializer = ReportSerializer(reports, many=True)
            # product_serializer = ProductSdetailserializer(product)
            
                product_data = {
                    'product': product_serializer.data,
                    'reports': report_serializer.data
                }
                response_data.append(product_data)
        response_data = sorted(response_data, key=lambda x: x['product']['id'], reverse=True)
        
        return Response(response_data, status=status.HTTP_200_OK)