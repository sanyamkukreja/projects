from django.apps import AppConfig


class HelpSupportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Help_Support'
