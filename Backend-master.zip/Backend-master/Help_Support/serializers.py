from rest_framework import serializers
from .models import *


class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = ['id', 'question','answer','type']


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone','is_vendor','is_buyer']  # Add 'phone' if it exists
        ref_name = 'HelpSupportUserSerializer'

class UserdetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone'] 
       

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product 
        fields = ['id', 'title']


class ProductSdetailserializer(serializers.ModelSerializer):
    user = UserdetailSerializer()  # Assuming UserSerializer exists

    class Meta:
        model = Product 
        fields = '__all__'

class ListReportSerializer(serializers.ModelSerializer): 
    
    buyer = UserSerializer(read_only=True)
    seller = UserSerializer(read_only=True)
    product = ProductSerializer(read_only=True)  

    class Meta:
        model = Report
        fields = ['id', 'buyer', 'seller', 'product', 'subject', 'description', 'status','user_type','api_type','report_list']


class ReportSerializer(serializers.ModelSerializer): 
    
    
    class Meta:
        model = Report
        fields = ['id', 'buyer', 'seller', 'product', 'subject', 'description', 'status','user_type','api_type','report_list']
 
    def validate(self, data):

        api_type = data.get('api_type')
        user_type = data.get('user_type')
        buyer = data.get('buyer')
        seller = data.get('seller')
    

        if user_type == 'buyer':
            if not buyer or buyer.is_buyer  == False:
                raise serializers.ValidationError({'error': "User Does Not Exist"})
            elif api_type == 'report':
                # Check if the required fields are provided
                required_fields = ['buyer', 'seller', 'product','report_list']
                for field in required_fields:
                    if field not in data:
                        raise serializers.ValidationError({field: ["This field is required."]})
                    
            elif api_type == 'help':  
                # Check if the required fields are provided
                required_fields = ['buyer', 'subject', 'description']
                for field in required_fields:
                    if field not in data:
                        raise serializers.ValidationError({field: ["This field is required."]})

        elif user_type == 'seller':  
            if not seller or seller.is_vendor == False:
                raise serializers.ValidationError({'error': "User Does Not Exist"})
            if api_type == 'help':
                # Check if the required fields are provided
                required_fields = ['seller', 'subject', 'description']
                for field in required_fields:
                    if field not in data:
                        raise serializers.ValidationError({field: ["This field is required."]})
        return data

