# ############ form application code ###########
# from django.shortcuts import render

# Create your views here.

from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from login_signup.custom_authentication import CustomJWTAuthentication
from product.models import FavProduct
# from login_signup.custom_authentication import CustomJWTAuthentication
# from login_signup.custom_permissions import IsCustomUser
from .models import *
from .serializers import *
from itertools import groupby
from drf_spectacular.utils import extend_schema
from django_filters.rest_framework import DjangoFilterBackend
from django.utils import timezone
from datetime import timedelta
import django_filters
from suscription.models import subscribe
from rest_framework.permissions import AllowAny

from rest_framework.filters import SearchFilter

from django.db.models import Q,Case, When, IntegerField,CharField
from suscription.custom_pagination import CustomPagination
# Create your views here.

class CategoryFilter(django_filters.FilterSet):
    category_name = django_filters.CharFilter(field_name='category_name', lookup_expr='icontains')

    class Meta:
        model = Category
        fields = ['category_name']

class CategoryMVS(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySer
    filter_backends = [DjangoFilterBackend]
    filterset_class = CategoryFilter
   # pagination_class = CustomPagination

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    def partial_update(self, request, pk=None): 
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({"error": "Category not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.get_serializer(category, data=request.data, partial=True,context={'request':request})
        if serializer.is_valid():
            serializer.save()
            return Response({'msg':'category updated','data': serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, context={'request': request})
        
        # Retrieve all subcategories related to the category
        subcategories = instance.mainform_belong_to.order_by('-id')
        subcategory_serializer = SubCategorySer(subcategories, many=True,context={'request': request})
        
        # Include subcategories in the response data
        response_data = serializer.data
        response_data['subcategories'] = subcategory_serializer.data
        
        return Response(response_data)
    
    
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset()).order_by('-id')
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True, context={'request': request})
        #     return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True, context={'request': request})
        return Response({'msg':'list product of category','data':serializer.data})


    def create(self, request, *args, **kwargs):
        data = request.data.copy()  # Make a mutable copy of the request data
        if 'icon' not in data or not data['icon']:
            return Response({'error': 'Please select category image'}, status=status.HTTP_400_BAD_REQUEST)
        
        serializer = self.get_serializer(data=data,context={'request': request})
        serializer.is_valid(raise_exception=True) 
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response({'msg': 'Product category created', 'data': serializer.data}, status=status.HTTP_201_CREATED, headers=headers)
    
# @extend_schema(parameters=[{'name': 'id', 'required': True, 'type': 'integer', 'in': 'path'}])
class WebsiteCategoryViewSet(viewsets.ModelViewSet):
    queryset = WebsiteCategory.objects.all()
    serializer_class = WebsiteCategorySer
   # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):

        serializer = WebsiteCategorySer(data = request.data)

        serializer.is_valid(raise_exception=True)

        
        str_having_digits = serializer.validated_data.get('category_list')
        if not WebsiteCategory.objects.exists():
            WebsiteCategory.objects.create(category_list = str_having_digits)
        else:
            obj = WebsiteCategory.objects.first()
            obj.category_list = str_having_digits
            obj.save()

        characters = str_having_digits.split(',')

        categories_list = [int(char) for char in characters]

        categories_objs_list = [Category.objects.get(id = category_id) for category_id in categories_list]

        for cat in categories_objs_list:
            
            category_ser_list = [CategorySer(cat).data for cat in categories_objs_list]

        return Response({'msg':'WebsiteCategory', 'data':category_ser_list},status=status.HTTP_200_OK)
    
    def list(self, request, *args, **kwargs):
        obj = WebsiteCategory.objects.first()

        if obj == None:
            return Response({'error':'No category exist in database'},status=status.HTTP_400_BAD_REQUEST)

        cat_list = obj.category_list

        characters = cat_list.split(',')

        categories_id_list = [int(char) for char in characters]

        category_obj_list = [Category.objects.get(id = category_id) for category_id in categories_id_list]
        # page = self.paginate_queryset(category_obj_list )
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        category_list_ser = [CategorySer(category_obj).data for category_obj in category_obj_list]

        return Response({'msg':'Get api run seccessfully', 'data':category_list_ser},status=status.HTTP_200_OK)


class SubCategoryFilter(django_filters.FilterSet):
    subcategory_name = django_filters.CharFilter(field_name='subcategory_name', lookup_expr='icontains')
    category = django_filters.CharFilter(field_name='category__category_name', lookup_expr='icontains')

    class Meta:
        model = SubCategory
        fields = ['subcategory_name', 'category']


class SubCategoryMVS(viewsets.ModelViewSet):
    queryset = SubCategory.objects.all().order_by('-id')
    serializer_class = SubCategorySer
    filter_backends = [DjangoFilterBackend]
    filterset_class = SubCategoryFilter
   # pagination_class = CustomPagination

    def partial_update(self, request, pk=None):
        try:
            subcategory = SubCategory.objects.get(pk=pk)
        except SubCategory.DoesNotExist:
            return Response({"error": "subCategory not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.get_serializer(subcategory, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg':'updated','data': serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset()).order_by('-id')
        page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True, context={'request': request})
        #     return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True, context={'request': request})
        return Response({'msg': 'List of active subcategories', 'data': serializer.data}) 

    def create(self, request, *args, **kwargs):
        data = request.data.copy()  # Make a mutable copy of the request data
        if 'icon' not in data or not data['icon']:
            return Response({'error': 'Please select subcategory image'}, status=status.HTTP_400_BAD_REQUEST)
        subcategory_name = data.get('subcategory_name')
        category_id = data.get('category')
        if SubCategory.objects.filter(subcategory_name=subcategory_name, category_id=category_id).exists():
            return Response({'error': 'This subcategory already exists for the selected category.'}, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data) 
        return Response({'msg': 'Product subcategory created', 'data': serializer.data}, status=status.HTTP_201_CREATED, headers=headers)


from django.shortcuts import get_object_or_404
from django.db.models import Case, When, BooleanField, Value,F

  
class ProductMVS(viewsets.ModelViewSet):
    queryset = Product.objects.all() 
    serializer_class = ProductSer
    pagination_class = CustomPagination
    # authentication_classes=[CustomJWTAuthentication]
    # filter_backends = [DjangoFilterBackend]
    # filterset_class = ProductFilter

    def list(self, request):
        # Retrieve filter parameters from request
        is_buyer = request.query_params.get('is_buyer')
        category_id = request.query_params.get('category_id')
        original_price = request.query_params.get('original_price')  
        discount_price = request.query_params.get('discount_price')
        discount_min = request.query_params.get('discount_price_min')
        discount_max = request.query_params.get('discount_price_max')
        ratings = request.query_params.getlist('rating')
        user_id = request.query_params.get('user_id')
        buyer_id = request.query_params.get('buyer_id')
        global_keyword = request.query_params.get('search')
        payment_status= request.query_params.get('payment_status')
       
        queryset = Product.objects.all()
    
        # Apply filters based on parameters
        if category_id:
            queryset = queryset.filter(category_id=category_id)
        if discount_min:
            queryset = queryset.filter(discount_price__gte=discount_min)
        if discount_max:
            queryset = queryset.filter(discount_price__lte=discount_max)  
        
        if ratings:
            queryset = queryset.filter(product_review__rating__in=ratings)

        if user_id:
            queryset = queryset.filter(user_id=user_id)
            
        if payment_status:
            queryset= queryset.filter(payment_status=payment_status)

        if discount_price:  # New: Filter by price if provided
            queryset = queryset.filter(discount_price=discount_price)
   
        if buyer_id:
            buyer = get_object_or_404(User, id=buyer_id)
            fav_product_ids = FavProduct.objects.filter(user=buyer).values_list('product_id', flat=True)
            queryset = queryset.annotate(
                is_wishlist=Case(
                    When(id__in=fav_product_ids, then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField()
                )
            )
        if global_keyword:
            queryset = queryset.filter(
                Q(category__category_name__icontains=global_keyword) |
                Q(sub_category__subcategory_name__icontains=global_keyword) |
                Q(title__icontains=global_keyword) |
                Q(description__icontains=global_keyword) |
                Q(product_form_data__icontains=global_keyword) |
                Q(user__full_name__icontains=global_keyword)
            )
            
        queryset = queryset.order_by('-id')
        if is_buyer:
            queryset= queryset.filter(payment_status='paid' , availability_status = 'available', status='active')
            queryset = queryset.order_by(
                Case(
                    When(user__user_plan__plan__name='Gold', then=Value(1)),
                    When(user__user_plan__plan__name='Silver', then=Value(2)),
                    When(user__user_plan__plan__name='Free', then=Value(3)),
                    default=Value(4),  # Fallback to ensure any other plans are after gold, silver, free
                    output_field=IntegerField(),
                ),
                '-id'  # Secondary sorting by ID descending
            )
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = ProductSer(queryset, many=True,context={'request':request})
        return Response({'msg':'list of products form','data':serializer.data},status=status.HTTP_200_OK)
    

    def retrieve(self, request, pk=None):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)

        user_id = request.query_params.get('user_id')

        if user_id:
            viewed_user_list = product.viewed_user_list.split(',')
            if user_id not in viewed_user_list:
                # Increment views and update viewed_user_list
                product.views += 1
                if product.viewed_user_list:
                    product.viewed_user_list += f',{user_id}'
                else:
                    product.viewed_user_list = user_id
                product.save()

        serializer = self.get_serializer(product)
        return Response({'msg':'list of product','data':serializer.data},status=status.HTTP_200_OK)
    
    
    def create(self, request, *args, **kwargs):
        user_id = request.data.get('user')
        if user_id:
            try:
                user = User.objects.get(id=user_id)
            except User.DoesNotExist:
                return Response({'msg': 'User does not exist.'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'msg': 'User ID is required.'}, status=status.HTTP_400_BAD_REQUEST)

    # Get the user's subscription plan
        subscription=subscribe.objects.get(user=user_id)
        if not subscription:
            return Response({'msg': 'User does not have an active subscription.'}, status=status.HTTP_400_BAD_REQUEST)

        plan_name = subscription.plan.name
        product_limit = subscription.plan.limit if plan_name in ['Silver', 'Free'] else float('inf')
        # Count the user's existing products
        user_product_count = user.count
        user_status=subscription.is_expired
        # Check if the user has reached the product limit
        if int(user_product_count) >= product_limit:
            return Response({'msg': 'Product limit reached. Upgrade your plan to add more products.'}, status=status.HTTP_400_BAD_REQUEST)
        if user_status is True:
            return Response({'msg':'Subscription plan expired please upgrade your plan'})
        payment= request.data.get('payment_status')
        if  payment == "paid"  :   
            user.count += 1
            user.save()
        serializer = self.get_serializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer) 
       
        return Response({'msg':'Product created successfully ','data':serializer.data},status=status.HTTP_201_CREATED)
    # def perform_create(self, serializer, uploaded_images):
    #     product = serializer.save()
    #     uploaded_images = self.request.FILES.getlist('uploaded_images')
    #     for image in uploaded_images:
    #         ProImage.objects.create(product=product, images=image)
    def partial_update(self, request, pk=None):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = self.get_serializer(product, data=request.data, partial=True,context={'request':request})
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response({'data':'product updated','data':serializer.data}, status=status.HTTP_200_OK)
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        user = instance.user   
        # Check if the payment status is 'paid'
        if instance.payment_status == 'paid':
            user.count -= 1
        
        self.perform_destroy(instance)
        user.save()
        
        return Response({'msg': 'Product deleted successfully'}, status=status.HTTP_204_NO_CONTENT)
    


class VendorProductListMVS(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSer
    authentication_classes = [CustomJWTAuthentication]   
   # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):
        vendor_id= request.user.id
        product_obj = Product.objects.filter(user_id = vendor_id)

        product_ser = ProductSer(product_obj, many=True)

        return Response({'data':product_ser.data},status=status.HTTP_200_OK)
    
    def list(self, request, *args, **kwargs):
        vendor_id = request.user.id
        # Filter products by user and payment_status = "paid"
        product_obj = Product.objects.filter(user_id=vendor_id, payment_status="paid")
        # Check if the filtered queryset is empty or not
        if not product_obj.exists():
            return Response({'error': 'No products found', 'data': []}, status=status.HTTP_404_NOT_FOUND)
        # page = self.paginate_queryset(product_obj)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        product_ser = ProductSer(product_obj, many=True)

        return Response({'data': product_ser.data}, status=status.HTTP_200_OK)

    
        

class ListProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ListProductSer
   # pagination_class = CustomPagination

    

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        serializer = self.get_serializer(queryset, many=True)
        discount_price = []
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)

        for ser_obj in serializer.data:
            discount_price.append(ser_obj['discount_price'])

        # return Response(serializer.data)
        return Response({'msg':'list of products','price':discount_price},status=status.HTTP_200_OK)



class FavProductViewSet(viewsets.ModelViewSet):
    queryset = FavProduct.objects.all()
    serializer_class = FavProductSer
   # pagination_class = CustomPagination
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        serializer = FavProductSer(queryset, many=True,context={'request':request})
        return Response({'msg':'list of favourite products','data':serializer.data})
    
    def create(self, request):
        serializer = FavProductSer(data = request.data,context={'request':request})
        serializer.is_valid(raise_exception = True)  
        user = serializer.validated_data['user']  
        if user.is_buyer==False:
            return Response({'error': 'you do not have permission'}, status=status.HTTP_403_FORBIDDEN)
        product = serializer.validated_data['product']
        existing_fav = FavProduct.objects.filter(user = user, product = product).first()
        if existing_fav:
            existing_fav.delete()
            return Response({'msg': 'Product removed from favorites'}, status=status.HTTP_204_NO_CONTENT)   
        else:
            serializer.save()
            return Response({'msg': 'Product added to favorites','data':serializer.data}, status=status.HTTP_201_CREATED)
    @extend_schema(operation_id='retrieve_products_by_user_id')
    @action(detail=False, methods=['get'], url_path='(?P<user_id>[^/.]+)')
    def list_by_user(self, request, user_id=None): 
        queryset = self.get_queryset().filter(user_id=user_id)
        page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True,context={'request':request}) 
        # for product in serializer.data:
        #     product['product']['is_wishlist'] = True
        return Response({'msg': 'Favorite products list fetched successfully', 'data': serializer.data}, status=status.HTTP_200_OK)



class ReviewViewSet(viewsets.ModelViewSet):
    queryset = Review.objects.all()
    serializer_class = ReviewSer 
   # pagination_class = CustomPagination

    permission_classes=[AllowAny] 
    def get_queryset(self):
        queryset = Review.objects.all()
        product_id = self.request.query_params.get('product', None)
        if product_id is not None:
            queryset = queryset.filter(product_id=product_id)
        return queryset

    def update(self, request, *args, **kwargs):
        return Response("working on update",status=status.HTTP_200_OK)
    


class HelpFullViewSet(viewsets.ModelViewSet):
    queryset = HelpFull.objects.all()
    serializer_class = HelpFullSer
   # pagination_class = CustomPagination

    def create(self, request):
        serializer = self.get_serializer(data = request.data)

        serializer.is_valid(raise_exception = True)

        user = serializer.validated_data['user']  
        review = serializer.validated_data['review']  
        helpfull = serializer.validated_data['helpfull']  

        hf_obj = HelpFull.objects.filter(user = user, review = review).first()

        if hf_obj:
            if hf_obj.helpfull == helpfull:
                hf_obj.delete()
                return Response({'msg':'HelpFull is removed due to again click'}, status = 200)
            else:
                hf_obj.helpfull = False
                return Response({'msg':'HelpFull is removed'})

        else:

            if helpfull == False:
                return Response({'msg':'Review is already marked as not HelpFull'},status=status.HTTP_200_OK)
            
            helpfull_obj = HelpFull.objects.create(user = user, review = review, helpfull = helpfull)

            ser_obj = HelpFullSer(helpfull_obj)

            return Response({'msg':'This review is HelpFull', 'data':ser_obj.data}, status=status.HTTP_200_OK)



class FormMVS(viewsets.ModelViewSet):
    
    queryset = Form.objects.all()
    serializer_class = FormSer
   # pagination_class = CustomPagination

    def list(self, request, *args, **kwargs):
        sub_category_id = request.query_params.get('sub_category')
        if sub_category_id is not None:
            queryset = self.get_queryset().filter(subcategory=sub_category_id)
            if queryset.exists():
                serializer = self.get_serializer(queryset.first())
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response({'message': 'No objects found for the specified subcategory.'},status=status.HTTP_400_BAD_REQUEST)
        else:
            # return Response({'message': 'Subcategory ID is required as a query parameter.'}, status=400)
            queryset = self.get_queryset()
            ##page = self.paginate_queryset(queryset)
       #     if page is not None:
            #    serializer = self.get_serializer(page, many=True)
            #    return self.get_paginated_response(serializer.data)
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data,status=status.HTTP_200_OK)

    


class DynamicFormMVS(viewsets.ModelViewSet):

    queryset = DynamicForm.objects.all()
    serializer_class = DynamicFormSer
   # pagination_class = CustomPagination

    def list(self, request, *args, **kwargs):
        category_id = request.query_params.get('category_id')
        sub_category_id = request.query_params.get('sub_category_id')

        if category_id and sub_category_id:
            queryset = self.get_queryset().filter(category=category_id, subcategory=sub_category_id).order_by('-id')
            if queryset.exists():
                serializer = self.get_serializer(queryset, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response({'message': 'The specified category and subcategory do not have an associated form.'}, status=status.HTTP_400_BAD_REQUEST)

        elif category_id:
            queryset = self.get_queryset().filter(category=category_id).order_by('-id')
            if queryset.exists():
                serializer = self.get_serializer(queryset, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response({'message': 'The specified category do not have an associated form.'}, status=status.HTTP_400_BAD_REQUEST)

        elif sub_category_id:
            queryset = self.get_queryset().filter(subcategory=sub_category_id).order_by('-id')
            if queryset.exists():
                serializer = self.get_serializer(queryset, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response({'message': 'The specified subcategory do not have an associated form.'}, status=status.HTTP_400_BAD_REQUEST)

        else:
            queryset = self.get_queryset().order_by('-id')
            serializer = self.get_serializer(queryset, many=True)
            return Response({'msg':'list of dynamic forms','data':serializer.data},status=status.HTTP_200_OK)

class OfferModelViewSet(viewsets.ModelViewSet):
    queryset = OfferModel.objects.all()
    serializer_class = OfferModelSerializer  
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAuthenticated]
   # pagination_class = CustomPagination
    
    def get_serializer_class(self):
        if self.action == 'create':
            return OfferModelCreateSerializer
        return OfferModelSerializer

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response({'msg':'list of offers for respective vendor','data':serializer.data})
    
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response({'msg': 'offer is successfully send to respective vendor '}, status=status.HTTP_200_OK, headers=headers)




class ProductOfferViewSet(viewsets.ViewSet):
    def list(self, request):
        products = Product.objects.all()
        response_data = []

        for product in products:
            offers = OfferModel.objects.filter(product=product).order_by('-id')
            if offers.exists():
                offer_serializer = OfferModelSerializer(offers, many=True)
                product_serializer = ProductSer(product,context={'request':request})
            # report_serializer = ReportSerializer(reports, many=True)
            # product_serializer = ProductSdetailserializer(product)
            
                product_data = {
                    'product': product_serializer.data,
                    'offers': offer_serializer.data
                }
                response_data.append(product_data)
        response_data = sorted(response_data, key=lambda x: x['product']['id'], reverse=True)
        
        return Response(response_data, status=status.HTTP_200_OK)