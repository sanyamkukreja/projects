# ########## form application code ##########
# from django.contrib import admin

# Register your models here.


from django.contrib import admin
from .models import *

# @admin.register(Category)
# class CategoryAdmin(admin.ModelAdmin):
#     pass

# @admin.register(SubCategory)
# class SubCategoryAdmin(admin.ModelAdmin):
#     pass

# @admin.register(Form)
# class FormAdmin(admin.ModelAdmin):
#     pass

admin.site.register(Category)
admin.site.register(SubCategory)
# admin.site.register(Form)
# admin.site.register(FormField)

# class FormFieldInline(admin.StackedInline):
#     model = FormField
#     extra = 1

# class FormAdmin(admin.ModelAdmin):
#     inlines = [FormFieldInline]

# admin.site.register(Form, FormAdmin)



# #####################################
# from django.contrib import admin
# from .models import Category, SubCategory

# # Register your models here.

# @admin.register(Category)
# class CategoryAdmin(admin.ModelAdmin):
#     list_display = ['id','name']
#     search_fields = ['name']

# @admin.register(SubCategory)
# class SubcategoryAdmin(admin.ModelAdmin):
#     list_display = ['id','name', 'category']
#     list_filter = ['category']
#     search_fields = ['name']





