# ################# code of form application ################
# from django.db import models

# Create your models here.

from django.db import models
from django.utils import timezone

from login_signup.models import User
from django.conf import settings
# Create your models here.

class Category(models.Model):
    category_name = models.CharField(max_length= 255,unique=True,blank = True)
    icon = models.ImageField(upload_to = 'e360/category/icon/',default='')
    active = models.BooleanField(default=True)

    # icon = models.FileField(upload_to = 'category/icon/', blank = True, null = True)
    def get_icon_url(self):
        if self.icon:
            return self.icon.url
        return ''
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['icon_url'] = self.get_icon_url(instance)
        return representation
    

class WebsiteCategory(models.Model):
    category_list = models.CharField(max_length=255, null = True, blank = True)

class SubCategory(models.Model):
    category = models.ForeignKey(Category, on_delete = models.CASCADE ,related_name = "mainform_belong_to", blank=True)
    subcategory_name = models.CharField(max_length=255,blank = True)
    icon = models.ImageField(upload_to = 'e360/subcategory/icon/', blank = True, null = True)
    active = models.BooleanField(default=True)

    def get_icon_url(self):
        if self.icon:
            return self.icon.url
        return ''
    

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['icon_url'] = self.get_icon_url(instance)
        return representation
    
    # class Meta:
    #     unique_together = ('category_name', 'subcategory_name')


    
class Product(models.Model):
    PAYMENT_STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('paid', 'Paid'),
    ]
    STATUS_CHOICES = [
        ('active','Active'),
        ('inactive','Inactive')
    ]
    Availability_status=[
        ('available','Available'),
        ('out of stock','Out of stock')
    ]
    Type=[
        ('new','New'),
        ('old','Old')
    ]

    
    images = models.ImageField(upload_to='e360/product/images/', blank = True, default='', null = True)
    category = models.ForeignKey(Category, on_delete = models.CASCADE, related_name = 'category_product')
    sub_category = models.ForeignKey(SubCategory, on_delete = models.CASCADE, related_name = 'sub_category_product', null = True)
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'products')
    title = models.CharField(max_length = 255, null=True, blank=True) 
    original_price = models.FloatField(null=True, blank = True)
    discount_price = models.FloatField(null=True, blank = True)
    description = models.TextField(null=True, blank = True)
    views = models.IntegerField(default = 0)
    viewed_user_list = models.CharField(max_length = 255, blank = True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    product_form_data = models.JSONField(null = True, blank = True)
    visibility_start_date = models.DateTimeField(default=timezone.now)  # Field to store visibility start date
    payment_status = models.CharField(
        max_length=10,
        choices=PAYMENT_STATUS_CHOICES,
        default='draft', 
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='active')
    
    availability_status = models.CharField(
        max_length=40,
        choices=Availability_status,
        default='available'
        )
    
    type = models.CharField(
        max_length=40,
        choices=Type,
        default='new'
        )
    warranty=models.TextField(blank=True,default='')

    
    


class ProImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name = "product_images")
    images = models.ImageField(upload_to='e360/product/images/', default="", null=True, blank=True)
    def get_image_url(self):
        if self.images:
            return self.images.url
        return ''
    
    



class FavProduct(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'user_favourite_products')
    product = models.ForeignKey(Product, on_delete = models.CASCADE, related_name = 'product_as_favourite')
    created_at = models.DateTimeField(default=timezone.now)
    
     

class Review(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'user_review')
    product = models.ForeignKey(Product, on_delete = models.CASCADE, related_name = 'product_review')
    review = models.CharField(max_length = 255)
    rating = models.FloatField(null=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
 
class HelpFull(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'user_helpfull_review')
    review = models.ForeignKey(Review, on_delete = models.CASCADE, related_name = 'helpfull_review')
    helpfull = models.BooleanField(default = False)

    

class Form(models.Model):
    subcategory = models.ForeignKey(SubCategory, on_delete = models.CASCADE, related_name = 'sub_category_form')
    form_field_value = models.JSONField(null = True)
    form_image = models.ImageField(upload_to = 'form/', null=True, blank=True)


class FormImage(models.Model):
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='image_of_form')
    form_image = models.ImageField(upload_to='e360/form/', null=True, blank=True)


class DynamicForm(models.Model):
    category = models.ForeignKey(Category, on_delete = models.CASCADE, related_name = 'dynamic_form_category')
    subcategory = models.ForeignKey(SubCategory, on_delete = models.CASCADE, related_name = 'dynamic_form_sub_category', null = True, blank = True)
    category_form = models.JSONField(null = True)
    sub_category_form = models.JSONField(null = True)
    category_form_status = models.BooleanField(blank = True, default=False)
    sub_category_form_status = models.BooleanField(blank = True, default=False)
    active = models.BooleanField(default=True)

    

    
    # form_image = models.ImageField(upload_to = 'form/', null=True, blank=True)

    

class OfferModel(models.Model):
    buyer = models.ForeignKey(User, on_delete=models.SET_NULL,related_name='buyer_offer' ,null=True, blank=True)
    seller = models.ForeignKey(User,related_name='seller_offer', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, blank=True)
    discount_price = models.DecimalField(max_digits=10, decimal_places=2)
    negotiation_price = models.DecimalField(max_digits=10, decimal_places=2) 

    