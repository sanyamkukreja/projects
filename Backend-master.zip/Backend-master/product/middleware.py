# myapp/middleware.py
from django.utils.deprecation import MiddlewareMixin
from .models import Product, User
from suscription.models import subscribe,Plan   
from rest_framework.response import Response
from rest_framework import status
from django.core.exceptions import ObjectDoesNotExist


class UpdateProductStatusMiddleware(MiddlewareMixin):
    def process_request(self, request):
        free_limit=(Plan.objects.get(name='free')).limit
        silver_limit=(Plan.objects.get(name='silver')).limit
        # Iterate over all users
        users = User.objects.all()
        
        for user in users:
            user_id=user.id
            
            if user_id:
                try:
                    user = User.objects.get(id=user_id)
                except User.DoesNotExist:
                    return Response({'msg': 'User does not exist.'}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'msg': 'User ID is required.'}, status=status.HTTP_400_BAD_REQUEST)
            try:
                subscription = subscribe.objects.get(user_id=user_id)
                plan_name = subscription.plan.name
                # Determine the number of products to keep active based on the user's plan and count
                if plan_name == "Free" and user.count > free_limit:
                    num_products_to_keep_active = free_limit
                elif plan_name == "Silver" and user.count > silver_limit:
                    num_products_to_keep_active = silver_limit
                else:
                    num_products_to_keep_active = 0
                
                if num_products_to_keep_active > 0:
                    products_to_keep_active_ids = list(
                        Product.objects.filter(user=user).order_by('-created_at').values_list('id', flat=True)[:num_products_to_keep_active]
                    )
                    
                    # Update the status of all other products to "inactive"
                    Product.objects.filter(user=user).exclude(id__in=products_to_keep_active_ids).update(status="inactive")
                # else:
            except ObjectDoesNotExist:
                # Handle the case where no subscription is found
                subscription = None      
            
