# ############## form application code ###############
from rest_framework import serializers

from login_signup.serializers import UserProfileSerializer,UserdataSer
from drf_spectacular.utils import extend_schema_field
from .models import *

from django.db.models import Avg


class CategorySer(serializers.ModelSerializer):
    # icon = serializers.ImageField(max_length = (10 * 1024 * 1024), required = False)
    icon_url = serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = Category
        fields = ['id', 'category_name', 'icon','icon_url','active']
        extra_kwargs = {'icon': {'write_only': True},'active': {'default': True}}
    @extend_schema_field(serializers.URLField)
    def get_icon_url(self, obj):
        request =self.context.get('request')
        if obj.icon and request != None:
            return request.build_absolute_uri(obj.icon.url)
        return ''
       
    def validate_icon(self, value):
        
        if value is None:
            return value
        value_max_size = (10 * 1024 * 1024)
        if value.size > value_max_size:
            raise serializers.ValidationError("File size should not be more than 10 MB")
        return value
    
    
    

class WebsiteCategorySer(serializers.Serializer):
       
    category_list = serializers.CharField(write_only = True)   


class SubCategorySer(serializers.ModelSerializer):
    icon_url = serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = SubCategory
       
        fields = ['id', 'category', 'subcategory_name','icon','icon_url','active']
        extra_kwargs = {'icon': {'write_only': True},'active': {'default': True}}

    def get_category(self, obj):
        request = self.context.get('request')
        return CategorySer(obj.category, context={'request': request}).data
    @extend_schema_field(serializers.URLField)
    def get_icon_url(self, obj):
        request = self.context.get('request')
        if obj.icon and request != None:
            return request.build_absolute_uri(obj.icon.url)
        return ''
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        # representation['category'] = CategorySer(instance.category).data
        representation['category'] = self.get_category(instance)
        # representation['sub_category'] = self.get_sub_category(instance)
        return representation

class ProductImageSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = ProImage
        fields = ['id', 'product','image_url','images']
        extra_kwargs = {'images': {'write_only': True},'product': {'write_only': True}}
    @extend_schema_field(serializers.URLField)
    def get_image_url(self, obj):
        request = self.context.get('request')
        if obj.images and request != None:
            return request.build_absolute_uri(obj.images.url)
        return ''
        
class ProductSer(serializers.ModelSerializer):

    product_images = ProductImageSerializer(many=True, read_only=True)
    is_wishlist=serializers.BooleanField(default=False)


    uploaded_images = serializers.ListField(
        child = serializers.ImageField(max_length = (10 * 1024 * 1024), allow_empty_file = False, use_url = False),
        write_only=True, required = False)
    deleted_images = serializers.CharField(write_only=True, required=False) 
    # ("\n ****** outer uploaded_images : ",uploaded_images,"\n ****** \n")

    class Meta:
        model = Product
        fields = ['id', 'product_images', 'category', 'sub_category', 'user', 'title', 'original_price','discount_price', 'description', 'views', 'viewed_user_list', 'created_at', 'updated_at', 'uploaded_images', 'product_form_data','payment_status','status','availability_status','type','deleted_images','warranty','is_wishlist']
        read_only_fields = ['views', 'viewed_user_list', 'created_at', 'updated_at']
    def validate_deleted_images(self, value):
        if value:
            ids = value.split(',')
            if not all(id.strip().isdigit() for id in ids):
                raise serializers.ValidationError("All IDs must be valid integers.")
        return value
    def validate_uploaded_images(self, value):
        for image in value:
            if image.size > (10 * 1024 * 1024):
                raise serializers.ValidationError("Image size exceeds the maximum allowed size of 10 MB.")
        return value
    def get_category(self, obj):
        request = self.context.get('request')
        return CategorySer(obj.category, context={'request': request}).data

    def get_sub_category(self, obj):
        request = self.context.get('request')
        return SubCategorySer(obj.sub_category, context={'request': request}).data
    def to_representation(self, instance):

        representation = super().to_representation(instance)    

        representation['user'] = UserProfileSerializer(instance.user).data

        reviews = Review.objects.filter(product = instance)
        representation['review'] = ReviewSer(reviews, many = True).data
        representation['category'] = self.get_category(instance)
        representation['sub_category'] = self.get_sub_category(instance)
        average_rating = Review.objects.filter(product=instance).aggregate(Avg('rating'))['rating__avg']

        if average_rating is not None:
            representation['avg_rating'] = int(average_rating)
        else:
            representation['avg_rating'] = 0
                
        return representation


    def create(self, validated_data):
        uploaded_images = validated_data.pop("uploaded_images", None)
        validated_data.pop('is_wishlist', None)
        product = Product.objects.create(**validated_data)
        
        if uploaded_images:
            for image in uploaded_images:
                ProImage.objects.create(product=product, images=image)
                if hasattr(image, 'close'):
                 image.close()
        
        return product
    
    def update(self, instance, validated_data):
        uploaded_images = validated_data.pop('uploaded_images', [])
        deleted_images = validated_data.pop('deleted_images', [])
        validated_data.pop('is_wishlist', None)
        new_payment_status = validated_data.get('payment_status', None)
        if new_payment_status is not None:
            previous_payment_status = instance.payment_status
            if previous_payment_status != new_payment_status:
                if previous_payment_status == 'paid' and new_payment_status == 'draft':
                    user=instance.user
                    user.count -=1
                    user.save()
                elif previous_payment_status == 'draft' and new_payment_status == 'paid':
                    user=instance.user
                    user.count +=1
                    user.save()
                instance.save()
        if deleted_images:
            deleted_images = [int(id.strip()) for id in deleted_images.split(',') if id.strip().isdigit()]
        if deleted_images:
            # instance.product_images.filter(id__in=deleted_images).delete()
            for image_id in deleted_images:
                instance.product_images.filter(id=image_id).delete()
        if uploaded_images:
            for image in uploaded_images:
                ProImage.objects.create(product=instance, images=image)
                if hasattr(image, 'close'):
                 image.close()
        return super().update(instance, validated_data)
    
class ListProductSer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id','original_price','discount_price']


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id','original_price','discount_price','images','title',]


class FavProductSer(serializers.ModelSerializer):
    # product = ProductSerializer() 
    class Meta:
        model = FavProduct
        fields = ['id','user', 'product']
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        request = self.context.get('request')
        product_serializer = ProductSer(instance.product, context={'request': request})
        representation['product'] = product_serializer.data
        return representation


class ReviewSer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ['id', 'user', 'product', 'review', 'rating', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at']

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        representation['user'] = UserdataSer(instance.user).data

        return representation


class HelpFullSer(serializers.ModelSerializer):
    class Meta:
        model = HelpFull
        fields = ['id', 'user', 'review', 'helpfull']

    
class FormImageSer(serializers.ModelSerializer):
    class Meta:
        model = FormImage
        fields = ['id', 'form', 'form_image']


class FormSer(serializers.ModelSerializer):
    image_of_form = FormImageSer(many = True, read_only = True)

    form_image = serializers.ListField(
        child = serializers.ImageField(max_length = 10000000, allow_empty_file = True, use_url = False),
        write_only=True, required = False)
    

    class Meta:
        model = Form
        # fields = ['id', 'mainform', 'field_type', 'form_field', 'field_value', 'form_data']
        fields = ['id', 'subcategory', 'form_field_value', 'form_image','image_of_form']


    def create(self, validated_data):
        
        form_image = validated_data.pop('form_image', None)

        form = Form.objects.create(**validated_data)

        if form_image:
            for f_image in form_image:
                FormImage.objects.create(form = form, form_image = f_image)

        return form

    def to_representation(self, instance):

        representation = super().to_representation(instance)

        representation['subcategory'] = SubCategorySer(instance.subcategory).data
        return representation



class DynamicFormSer(serializers.ModelSerializer):

    category_form_status = serializers.SerializerMethodField()
    sub_category_form_status = serializers.SerializerMethodField()
    @extend_schema_field(str)
    def get_category_form_status(self, obj):
        return bool(obj.category_form)  # Convert category_form to boolean
    @extend_schema_field(str)
    def get_sub_category_form_status(self, obj):
        return bool(obj.sub_category_form)  # Convert sub_category_form to boolean

    class Meta:
        model = DynamicForm
        fields = ['id','category'
                    ,'subcategory'
                    ,'category_form'
                    ,'sub_category_form'
                    ,'category_form_status'
                    ,'sub_category_form_status','active']
        
        extra_kwargs = {'active': {'default': True}}


    def get_category(self, obj):
        request = self.context.get('request')
        return CategorySer(obj.category, context={'request': request}).data
    
    def get_subcategory(self, obj):
        request = self.context.get('request')
        return SubCategorySer(obj.subcategory, context={'request': request}).data
   

    def to_representation(self, instance):

        representation = super().to_representation(instance)

        if representation.get('category') is not None:
            representation['category'] = self.get_category(instance)

        if representation.get('subcategory') is not None:
            representation['subcategory'] = self.get_subcategory(instance)

        return representation
    

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone']

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'title', 'discount_price']
        ref_name = 'ProductUserSerializer'



class OfferModelSerializer(serializers.ModelSerializer):
    seller = UserSerializer(read_only=True)
    buyer = UserSerializer(read_only=True)
    product = ProductSerializer(read_only=True)

    class Meta:
        model = OfferModel
        fields = ['id', 'seller', 'buyer', 'product', 'discount_price', 'negotiation_price']

class OfferModelCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = OfferModel
        fields = ['id', 'seller', 'buyer', 'product', 'discount_price', 'negotiation_price']
    
    def validate(self, data):
        if data['negotiation_price'] > data['discount_price']:
            raise serializers.ValidationError("Negotiation price cannot be greater than discount price.")
        return data