from django.db import models

from django.contrib.auth.models import AbstractUser
# from django.utils.translation import ugettext_lazy as _
from .managers import *


# Create your models here.

class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True) 
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    objects = CustomUserManager()
    STATUS_CHOICES = [
        ('registered','Registered'),
        ('otp verified','Otp Verified'),
        ('document uploaded','Document Uploaded'),
        ('rejected','Rejected'),
        ('inactive','Inactive'),
        ('approved','Approved'),
        ('reuploaded document','Reuploaded document')
    ]

    is_vendor = models.BooleanField(default=False) 
    is_buyer = models.BooleanField(default=False)
    full_name = models.CharField(max_length=100, null = True, blank = True)
    phone = models.CharField(max_length=20, null = True, blank = True)
    address = models.CharField(max_length=200, null = True, blank = True)
    apartment_number = models.CharField(max_length=50, null = True, blank = True)
    street_name = models.CharField(max_length=100, null = True, blank = True)
    city = models.CharField(max_length=100, null = True, blank = True)
    state = models.CharField(max_length=100, null = True, blank = True)
    zip_code = models.CharField(max_length=10, null=True, blank = True)
    t_and_c = models.BooleanField(default=False)
    location = models.TextField(null=True, blank=True)
    lat = models.FloatField(default=0.00)
    long = models.FloatField(default=0.00)
    otp = models.IntegerField(null = True, blank = True)
    otp_verified = models.BooleanField(default = False, null = True)
    shop_name = models.CharField(max_length=255,default='')
    doc1 = models.FileField(upload_to='e360/docs/', null=True, blank=True,default='')
    doc2 = models.FileField(upload_to='e360/docs/', null=True, blank=True,default='')
    doc3 = models.FileField(upload_to='e360/docs/', null=True, blank=True,default='')
    doc4 = models.FileField(upload_to='e360/docs/', null=True, blank=True,default='')
    image = models.ImageField(upload_to='e360/images/',default='',null=True,blank=True)
    is_document = models.BooleanField(default=False) 
    reason=models.TextField(default='',blank=True,null=True)  
    design=models.JSONField(default=dict,blank=True,null=True)
    count=models.IntegerField(default=0)
    status = models.CharField(
        max_length=50,
        choices=STATUS_CHOICES,
        default='registered',blank=True,null=True)
    # remember_me = models.BooleanField(default=False)
    # device_ip=models.TextField(default='',blank=True,null=True)
    




    




