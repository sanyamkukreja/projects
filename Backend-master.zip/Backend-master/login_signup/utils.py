from django.core.mail import EmailMessage
import os
from django.core.mail import send_mail
# Import for OTP
from twilio.rest import Client  # Import the Twilio Client if using Twilio
import string
import random
from django.conf import settings
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

def send_email_to_client(data):
    message = Mail(
        from_email=settings.DEFAULT_FROM_EMAIL,
        to_emails=data['to_email'],
        subject=data['subject'],
        plain_text_content=data['body']
    )

    try:
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        response = sg.send(message)
        return {
            'status': 'success',
            'status_code': response.status_code,
            'body': response.body,
            'headers': response.headers
        }
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e)
        }
    

# def 

# OTP verification which comes on mobile  number
def generate_otp(length=4):
    characters = string.digits
    otp = ''.join(random.choice(characters) for _ in range(length))
    return otp

# https://console.twilio.com/

def send_otp_phone(phone_number, otp):
    # account_sid = 'your_account_sid'  # Replace with your Twilio account SID
    account_sid = 'AC787e1b6fa64dd02b03e7dc7f47c717d1'  # Replace with your Twilio account SID
    # auth_token = 'your_auth_token'  # Replace with your Twilio auth token
    auth_token = 'a38df6ba17377dbfb3b9be9684ec1d0a'  # Replace with your Twilio auth token
    # twilio_phone_number = 'your_twilio_phone_number'  # Replace with your Twilio phone number
    twilio_phone_number = '+14247329884'  # Replace with your Twilio phone number

    client = Client(account_sid, auth_token)  
    message = client.messages.create(
        body=f'Your OTP is: {otp}',
        from_=twilio_phone_number, 
        to=phone_number   
    )


import random
import string

def generate_strong_password():
    length = 12
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for i in range(length))
    return password

def send_email(data):
    # Create the Mail object with HTML content
    message = Mail(
        from_email=settings.DEFAULT_FROM_EMAIL,
        to_emails=data['to_email'],
        subject=data['subject'],
        html_content=data['body']  # Use html_content instead of plain_text_content
    )

    try:
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        response = sg.send(message)
        return {
            'status': 'success',
            'status_code': response.status_code,
            'body': response.body,
            'headers': response.headers
        }
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e)
        }