from django.core.management.base import BaseCommand
from django.core.cache import cache

class Command(BaseCommand):
    help = 'Test Redis connection'

    def handle(self, *args, **kwargs):
        try:
            cache.set('test_key', 'test_value', timeout=10)
            value = cache.get('test_key')
            if value == 'test_value':
                self.stdout.write(self.style.SUCCESS('Successfully connected to Redis'))
            else:
                self.stdout.write(self.style.ERROR('Failed to connect to Redis'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {e}'))
