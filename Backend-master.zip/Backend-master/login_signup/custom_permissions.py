# from rest_framework.permissions import BasePermission
# # from rest_framework import permissions
# # from .models import UserModel

# from django.contrib.auth import get_user_model

# User = get_user_model()


# class IsCustomAdmin(BasePermission):
#     def has_permission(self, request, view):
#         return request.user and isinstance(request.user, User) and request.user.is_superuser


# class IsVendor(BasePermission):
#     def has_permission(self, request, view):
#         # print("\n **** request.user permission **** \n",request.user)
#         if request.user and isinstance(request.user, User) and request.user.is_vendor:
#             return True


# class IsBuyer(BasePermission):
#     def has_permission(self, request, view):      
#         if request.user:
#             if isinstance(request.user, User) and request.user.is_buyer:
#                 return True


# class IsCustomIsAdminOrReadOnly(BasePermission):
#     def has_permission(self, request, view):

#         if request.method == 'GET':
#             return True
        
#         if request.user:
#             if isinstance(request.user, User) or isinstance(request.user, User):
#                 return True
            



            