from django.shortcuts import render
from rest_framework import viewsets,status
from django.shortcuts import get_object_or_404
from product.views import FavProductViewSet
from .models import *
from .serializers import *
from rest_framework.response import Response
from .utils import * 
from sendgrid.helpers.mail import Mail
from sendgrid import SendGridAPIClient
from PIL import Image
import imghdr 
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.response import Response
from geopy.distance import geodesic
from product.serializers import ProductSer
from product.models import Product,FavProduct
from rest_framework.decorators import action
from rest_framework.pagination import PageNumberPagination
from django.contrib import messages
from django.contrib.auth.hashers import check_password, make_password
from django.shortcuts import render, redirect
from rest_framework import viewsets, status
from rest_framework.permissions import AllowAny
# from suscription.custom_pagination import CustomPagination
from .custom_authentication import CustomJWTAuthentication 

from rest_framework_simplejwt.tokens import RefreshToken

from django.contrib.auth.models import Permission

# ////////////////////////

from django.http import HttpResponse
from django.core.cache import cache

def test_redis(request):
    try:
        cache.set('test_key', 'test_value', timeout=10)
        value = cache.get('test_key')
        if value == 'test_value':
            return HttpResponse("Successfully connected to Redis")
        else:
            return HttpResponse("Failed to connect to Redis")
    except Exception as e:
        return HttpResponse(f"Error: {e}")

# //////////////////

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class GroupCreateView(viewsets.ModelViewSet):

    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes=[AllowAny]
    # pagination_class = CustomPagination

class VendorUserPermissionViewSet(viewsets.ModelViewSet):
    # queryset = User.objects.filter(is_vendor = True)
    # queryset = Permission.objects.all()
    serializer_class = UserPermissionSer
    # pagination_class = CustomPagination

    def get_queryset(self):
        queryset = User.objects.filter(is_vendor = True)

        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)

        serializer = VendorProfileSer(queryset, many = True)

        return Response(serializer.data, status=status.HTTP_200_OK)
        

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data = request.data)  

        serializer.is_valid(raise_exception = True)

        # user_id = serializer.validated_data.get('user')
        # user = User.objects.filter(id = user_id)
        # Permission_id = serializer.validated_data.get('permission')

        serializer.save()

        return Response({'msg':'Permissions updated successfully'},status=status.HTTP_200_OK)


class AdminRegisterviewset(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_superuser=True)
    serializer_class = AdminRegisterser
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):
        # Generate a strong password
        generated_password = generate_strong_password()
        data = request.data.copy()  # Make a copy of the request data
        data['password'] = generated_password  # Set the generated password
        serializer = self.serializer_class(data=data)
        serializer.is_valid(raise_exception=True)
        validated_data = serializer.validated_data
        # Create the superuser with the validated data
        admin_user = User.objects.create_superuser(email=validated_data['email'],
        password=generated_password )
        full_name = validated_data.get('full_name')
        if full_name:
            admin_user.full_name = full_name
            admin_user.save()
         # Send email with the password
        email = serializer.validated_data['email']
        subject = 'Your admin account credentials'
        body = f"""
            <p>Your admin account has been created successfully.</p>
            <p>
                <strong>Email:</strong> {email}<br>
                <strong>Password:</strong> {generated_password}
            </p>
            """
        html_content = '<a href="http://appic-vince.s3-website-us-east-1.amazonaws.com/sign-in/admin" target="_blank">Login URL</a>'
        full_message = f"{body}</br></br>{html_content}"
        data = {
            'subject':subject,
            'body':full_message,
            'to_email':email
        }
        try:
          send_email(data)
        except Exception as e:
            return Response({'msg': 'Admin user created, but failed to send email. Error: {}'.format(e)}, status=status.HTTP_201_CREATED)
        # Return the response with the generated password
        return Response({
            'msg': 'Admin user created successfully',
            'password': generated_password
        }, status=status.HTTP_201_CREATED)
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        serializer = self.get_serializer(queryset, many=True)
        return Response({'msg': 'Admin list fetched successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
    
    
class AdminLoginViewSet(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_superuser=True) 
    serializer_class = AdminLoginSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)
        
        email = serializer.validated_data.get('email') 
        password = serializer.validated_data.get('password') 
        
        admin_user = User.objects.filter(email = email,is_superuser=True).first()

        if admin_user == None:
            return Response({'msg':'Admin user with this email id not exist'},status=status.HTTP_404_NOT_FOUND)
        
        if not check_password(password,admin_user.password):
            return Response({'msg':'Incorrect password'},status=status.HTTP_400_BAD_REQUEST)

        admin_user_obj = User.objects.filter(email = email).first()

        admin_ser = UserProfileSerializer(admin_user_obj)

        token = get_tokens_for_user(admin_user_obj)

        return Response({'msg':'Login successful', 'token':token, 'data':admin_ser.data},status=status.HTTP_200_OK) 

    def list(self, request, *args, **kwargs):
        queryset = User.objects.filter(is_vendor = False, is_buyer = False)

        serializer = self.serializer_class(queryset, many=True)

        return Response(serializer.data,status=status.HTTP_200_OK)

class AdminPasswordResetRequestViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = AdminPasswordResetRequestSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data.get('email')
        admin_user = User.objects.filter(email = email).first()

        if admin_user == None:
            return Response({'msg':'Email not registered. Please sign up.'},status=status.HTTP_404_NOT_FOUND)

        # Generate OTP
        otp = generate_otp()
        # GenerateOTP.objects.create(admin_user = admin_user, otp = otp)

        admin_user.otp = otp
        
        admin_user.save()

        # Send OTP via Email
        body = 'OTP is : '+ otp

        data = {
            'subject':'Email OTP for Admin password reset',
            'body':body,
            'to_email':email
        }

        send_email_to_client(data)

        return Response({'msg':f'OTP sent on {email} for admin password reset', 'otp':otp},status=status.HTTP_200_OK)



class AdminPasswordResetViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = AdminPasswordResetSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')
        confirm_password = serializer.validated_data.get('confirm_password')
    

        admin_user = User.objects.get(email = email)
        # otp_obj = GenerateOTP.objects.filter(admin_user = admin_user, otp=otp).first()
     
        if admin_user.otp_verified == False:
            return Response({'msg': 'OTP not verified'}, status=status.HTTP_400_BAD_REQUEST)
        if password != confirm_password:
            return Response({'msg': 'Password and confirm password does not match.'}, status=status.HTTP_400_BAD_REQUEST)
            
    
        admin_user.set_password(password)
        admin_user.save()
        return Response({'msg':f'Password reset successfully '},status=status.HTTP_200_OK)
       
        

   


# ***** Vendor
class VendorRegisterViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorRegisterSer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):

        data = request.data.copy()  # Make a mutable copy of the request data
        
        if 'image' in data and data['image']:
            # Check if the uploaded file is a valid image
            image_data = data['image']
            image_format = imghdr.what('', h=image_data.read())
            if not image_format:
                return Response({'msg': 'Please select a valid image'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Reset the file pointer for further processing
            image_data.seek(0)

            # Check if the uploaded file is an image using PIL
            try:
                image = Image.open(image_data)
                image.verify()  # Attempt to open and verify the image file
            except (IOError, SyntaxError) as e:
                return Response({'error': 'Please select a valid image'}, status=status.HTTP_400_BAD_REQUEST)
            finally:
                image_data.seek(0)

        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.validated_data.get('email')

        otp = generate_otp()

        vendor = serializer.save()

        vendor.otp = otp

        # vendor.set_password(vendor.password)
        vendor.is_active = False

        vendor.save()
        # Send OTP on Email
        body = 'OTP is : '+ otp
        data = {
            'subject':'Email OTP for Registration',
            'body':body,
            'to_email':email  
        }
        
        try:
            send_email_to_client(data)
        except Exception as e:
            return Response({'error':f"\n  ***** {e} ***** \n"})
        return Response({'msg':'OTP sent successfully'},status=status.HTTP_200_OK)
    
    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        if 'is_document' in request.data:
            instance.is_document = request.data['is_document']
            serializer.save()
            body=f'Your account is under admin verification. Please wait till admin approval'
            data = {
                'subject': 'Account under verification',
                'body': body,
                'to_email': instance.email
            }
            send_email_to_client(data)
            return Response({'msg':'Your profile created successfully','user_data':serializer.data},status=status.HTTP_200_OK)    
        else:    
            serializer.save()
            return Response({'msg':'Your profile updated successfully','user_data':serializer.data},status=status.HTTP_200_OK)
     
class VendorOTPVerifyViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorRegisterOTPVerifySer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.validated_data.get('email')
        otp = int(serializer.validated_data.get('otp'))

        vendor_user = User.objects.filter(email = email).first()

        if vendor_user == None:
            return Response({'error':f'User with this email does not exist'},status=status.HTTP_404_NOT_FOUND)

        if vendor_user.otp != otp:

            return Response({'error':'Invalid OTP'},status=status.HTTP_400_BAD_REQUEST)
        
        #vendor_user.is_active=True
        vendor = UserProfileSerializer(vendor_user)
        stored_otp = vendor_user.otp
        if stored_otp == otp:   
            # vendor_user.set_password(password)
            vendor_user.otp_verified = True
            vendor_user.save()
        # vendor_user.save()

        return Response({'msg':'OTP verified successfully','data':vendor.data},status=status.HTTP_200_OK)

    

class VendorLoginViewSet(viewsets.ViewSet):
    queryset = User.objects.all()
    serializer_class = VendorLoginSer
    # pagination_class = CustomPagination

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context
    
    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data,context={'request': request})
        serializer.is_valid(raise_exception=True)
    
        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')

        vendor_user = User.objects.filter(email = email).first()
        document_data = UserProfileSerializer(vendor_user,context={'request':request})
        if vendor_user == None:
            return Response({'msg':'Vendor user with this email id not exist'},status=status.HTTP_404_NOT_FOUND)
        
        if not check_password(password,vendor_user.password):
            return Response({'msg':'Incorrect password'},status=status.HTTP_400_BAD_REQUEST)
        if vendor_user.otp_verified == False:
            return Response({'msg': 'OTP not verified'}, status=status.HTTP_400_BAD_REQUEST)
        
        if vendor_user.is_document==False:  
            return Response({'error':'Your documents are not complete',"document_data":document_data.data},status=status.HTTP_400_BAD_REQUEST)
        if vendor_user.is_active==False and vendor_user.is_staff==False:
            return Response({'error':f'Your account is under admin verification. Please wait till admin approval'},status=status.HTTP_400_BAD_REQUEST)
        
        if vendor_user.is_active==False and vendor_user.is_staff==True:  
            body=f'Your account is rejected.  Reason is : {vendor_user.reason}'
            data = {
                'subject': 'Account rejected',
                'body': body,
                'to_email': email
            }

            send_email_to_client(data)
            return Response({'error':f'Your account is rejected.  Reason is : {vendor_user.reason}','data':document_data.data},status=status.HTTP_400_BAD_REQUEST)
        
        if vendor_user.is_staff==False:
            return Response({'error':'Your is not approved by admin'},status=status.HTTP_400_BAD_REQUEST)
        
        vendor_user_obj = User.objects.filter(email = email).first()

        vendor_ser = UserProfileSerializer(vendor_user_obj,context={'request':request})

        token = get_tokens_for_user(vendor_user_obj)

        return Response({'msg':'Login successful','token':token, 'data':vendor_ser.data},status=status.HTTP_200_OK) 



class VendorPasswordResetRequestViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorPasswordResetRequestSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):

        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        # phone_no = serializer.validated_data.get('phone')

        # vendor_user = User.objects.filter(email = email, phone = phone_no).first()
        vendor_user = User.objects.filter(email = email).first()

        if vendor_user == None:
            return Response({'msg':'Vendor user with this credentials does not exist'},status=status.HTTP_404_NOT_FOUND)

        # Generate OTP
        otp = generate_otp()
        # GenerateOTP.objects.create(admin_user = admin_user, otp = otp)

        vendor_user.otp = otp
        
        vendor_user.save()

        # Send OTP via Email
        body = 'OTP is : '+ otp

        data = {
            'subject':'Email OTP for vendor password reset',
            'body':body,
            'to_email':email
        }
    
        send_email_to_client(data)

        return Response({'msg':f'OTP sent sucessfully', 'otp':otp},status=status.HTTP_200_OK)



class VendorPasswordResetOTPVerifyViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = VendorPasswordResetOTPVerifySer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        otp = int(serializer.validated_data.get('otp'))

        vendor_user = User.objects.get(email = email)
        # otp_obj = GenerateOTP.objects.filter(admin_user = admin_user, otp=otp).first()
        stored_otp = vendor_user.otp

        if stored_otp == otp:   
            # vendor_user.set_password(password)
            vendor_user.otp_verified = True
            vendor_user.save()
            return Response({'msg':f' OTP verified successfully'},status=status.HTTP_200_OK)
        else:
            return Response({'msg':'Incorrect OTP'},status=status.HTTP_400_BAD_REQUEST)


class VendorPasswordResetViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorPasswordResetSer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')
        confirm_password = serializer.validated_data.get('confirm_password')

        vendor_obj = User.objects.filter(email = email).first()

        if vendor_obj.otp_verified == False:
            return Response({'error':'Incorrect OTP'},status=status.HTTP_400_BAD_REQUEST)
        
        vendor_obj.set_password(password)
  
        vendor_obj.save()

        return Response({'msg':f'Password reset successfully'},status=status.HTTP_200_OK)
    

# ***** Buyer Register
class BuyerRegisterViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = BuyerRegisterSer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.validated_data.get('email')
        otp = '1234'

        buyer = serializer.save()

        buyer.otp = otp

        # buyer.set_password(buyer.password)
        buyer.is_active = False
        buyer.save()

        # Send OTP on Email
        body = 'OTP is : '+ otp

        data = {
            'subject':'Email OTP for Registration',
            'body':body,
            'to_email':email
        }
        
        send_email_to_client(data)

        return Response({'msg':'OTP sent successfully'},status=status.HTTP_200_OK)
    
    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        query_params = request.query_params
        is_login = query_params.get('is_login', None)
        
        response_data = {
            'msg': 'User data updated successfully',
            'data': serializer.data,
        }

        if is_login:
            # Generate the token for the user using the custom function
            token = get_tokens_for_user(instance)
            response_data['token'] = token

        return Response(response_data, status=status.HTTP_200_OK)
        # return Response({'msg':'User data updated successfully','user_data':serializer.data},status=status.HTTP_200_OK)
    

class BuyerOTPVerifyViewSet(viewsets.ModelViewSet): 
    queryset = User.objects.all() 
    serializer_class = BuyerRegisterOTPVerifySer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.validated_data.get('email')
        otp = serializer.validated_data.get('otp')

        buyer_user = User.objects.filter(email = email).first()
   
        if buyer_user.otp != otp:
            return Response({'msg':'Invalid OTP'}, status = status.HTTP_200_OK)
        
        buyer_user.otp_verified=True
        buyer_user.is_active=True
        buyer_user.is_staff = True 
        buyer_user.save()
        buyer_ser = UserProfileSerializer(buyer_user)

        return Response({'msg':'OTP verified Successfully','data':buyer_ser.data}, status = status.HTTP_200_OK)
    


class BuyerPasswordResetRequestViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorPasswordResetRequestSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')

        buyer_user = User.objects.filter(email = email).first()

        if buyer_user == None:
            return Response({'msg':'Email not registered. Please sign up.'}, status = status.HTTP_404_NOT_FOUND)

        # Generate OTP
        otp = generate_otp()
        # GenerateOTP.objects.create(buyer_user = buyer_user, otp = otp)

        buyer_user.otp = otp

        buyer_user.save()

        # Send OTP via Email
        body = 'OTP is : '+ otp

        data = {
            'subject':'Email OTP for buyer password reset',
            'body':body,
            'to_email':email
        }

        send_email_to_client(data)

        return Response({'msg':f'OTP sent to registered email.',}, status = status.HTTP_200_OK)



class BuyerPasswordResetOTPVerifyViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = BuyerPasswordResetOTPVerifySer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        otp = int(serializer.validated_data.get('otp'))

        buyer_user = User.objects.get(email = email)
        # otp_obj = GenerateOTP.objects.filter(buyer_user = buyer_user, otp=otp).first()
        stored_otp = buyer_user.otp
        if stored_otp == otp:   
            # buyer_user.set_password(password)
            # buyer_user.password = password
            buyer_user.otp_verified = True
            buyer_user.save()
            return Response({'msg':f'OTP verified Successfully'}, status = status.HTTP_200_OK)
        else:
            return Response({'msg':'Incorrect OTP'}, status = status.HTTP_400_BAD_REQUEST)


class BuyerPasswordResetViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = BuyerPasswordResetSer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')

        buyer_user = User.objects.filter(email = email).first()

        if buyer_user.otp_verified == False:
            return Response({'error':'Invalid OTP'},status=status.HTTP_400_BAD_REQUEST)
        
        buyer_user.set_password(password)
        buyer_user.save()

        return Response({'msg':f'Password Change for Buyer Successfully for email {email}'},status=status.HTTP_200_OK)


class BuyerLoginViewSet(viewsets.ViewSet):
    queryset = User.objects.all()
    serializer_class = BuyerLoginSer 
    # pagination_class = CustomPagination

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True) 

        email = serializer.validated_data.get('email')
        password = serializer.validated_data.get('password')

        buyer_user = User.objects.filter(email=email).first()  
        if buyer_user is None:
            return Response({'msg': 'Email not registered. Please sign up.'}, status=status.HTTP_404_NOT_FOUND)
        
        if not check_password(password, buyer_user.password):
            return Response({'msg': 'Incorrect password'}, status=status.HTTP_400_BAD_REQUEST)
        
        if buyer_user.is_active==False:  
            return Response({'error':'buyer account is deactive'},status=status.HTTP_400_BAD_REQUEST)
        
        # if buyer_user.is_staff=='1':
        #     return Response({'error':'buyer is not approved by admin'},status=status.HTTP_400_BAD_REQUEST)
        
        if buyer_user.otp_verified == False:
            return Response({'msg': 'OTP is not verified!'}, status=status.HTTP_400_BAD_REQUEST)
        
        buyer_ser = BuyerRegisterSer(buyer_user)
        token = get_tokens_for_user(buyer_user)
        return Response({'msg': 'Login successful', 'token': token, 'data': buyer_ser.data}, status=status.HTTP_200_OK)

        # buyer_ser = BuyerRegisterSer(buyer_user_obj)

        # token = get_tokens_for_user(buyer_user_obj)

        # return Response({'msg': 'Buyer user logged in successfully', 'token': token, 'data': buyer_ser.data}, status=status.HTTP_200_OK)


class VendorProfile(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_vendor=True)
    serializer_class = VendorProfileSer
    # pagination_class = CustomPagination
    # authentication_classes = [CustomJWTAuthentication]

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        #page = self.paginate_queryset(queryset)
      #  if page is not None:
          #  serializer = self.get_serializer(page, many=True)
          #  return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True) 
        return Response({'msg': 'Vendor profiles fetched successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
    
    

    def retrieve(self, request, *args, **kwargs):
        vendor_id = request.user.id   

        vendor_obj = User.objects.filter(id = vendor_id , is_vendor = True).first()

        if vendor_obj == None:
            return Response({'error':'User not exist'},status=status.HTTP_404_NOT_FOUND)

        serializer = self.get_serializer(vendor_obj)

        return Response({'msg':'vendor profile fetched successfully','data':serializer.data}, status = status.HTTP_200_OK)
    
class BuyerProfile(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = BuyerProfileSer
    # pagination_class = CustomPagination
  
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().filter(is_buyer=True).order_by('-id')
        #page = self.paginate_queryset(queryset)
      #  if page is not None:
          #  serializer = self.get_serializer(page, many=True)
          #  return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response({'msg': 'buyer profiles fetched successfully', 'data': serializer.data}, status=status.HTTP_200_OK)

    def retrieve(self, request, pk = None):
        user_instance = self.get_object()
        # Favourite Products
        fav_product = user_instance.user_favourite_products.all()
        product_data = []
        for fav in fav_product:
            try:
                product = fav.product  # This may raise a DoesNotExist exception
                product_data.append(ProductSer(product, context={'request': request}).data)
            except Product.DoesNotExist:
                # Handle the case where the related product does not exist
                continue
        serializer = self.get_serializer(user_instance)
        return Response({"data":serializer.data,"favourite_products":product_data}, status = status.HTTP_200_OK)

class UserRetrieveViewSet(viewsets.ModelViewSet): 
    queryset = User.objects.all()
    serializer_class = UserProfileSerializer
    # pagination_class = CustomPagination
    # authentication_classes = [CustomJWTAuthentication] 

    def get_serializer_class(self):
        if self.action == 'create':
            return UserCreateSerializer
        return super().get_serializer_class()
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset().order_by('-id')
        #page = self.paginate_queryset(queryset)
      #  if page is not None:
          #  serializer = self.get_serializer(page, many=True)
          #  return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'msg': 'users fetch successfully',
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        fav_product = instance.user_favourite_products.all()
        fav_product_ids = instance.user_favourite_products.values_list('product__id', flat=True)

        product_data = []
        for fav in fav_product:
            try:
                product = fav.product  # This may raise a DoesNotExist exception
                product_data.append(product.id)
            except Product.DoesNotExist:
                # Handle the case where the related product does not exist
                continue
        serializer = self.get_serializer(instance)
        return Response({
            'msg': 'user fetch successfully',
            'data': serializer.data,
            'favourite_products':fav_product_ids
        }, status=status.HTTP_200_OK) 


class PermissonsRetrieveViewSet(viewsets.ModelViewSet): 
    queryset = Permission.objects.all()  
    serializer_class = PermissionSerializer 
    # pagination_class = CustomPagination


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorProfileSer
    # pagination_class = CustomPagination
    
    def list(self, request, *args, **kwargs):
        # Override the default list method to list all users (buyers and vendors)
        queryset = self.get_queryset()
        #page = self.paginate_queryset(queryset)
      #  if page is not None:
          #  serializer = self.get_serializer(page, many=True)
          #  return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def list_buyers(self, request):
        buyers = User.objects.filter(is_buyer=True)
        page = self.paginate_queryset(buyers)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(buyers, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def nearby_vendors_by_buyer(self, request):
        buyer_id = request.query_params.get('buyer_id')
        if not buyer_id:
            return Response({'error': 'Buyer ID is required as query parameter'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            buyer = User.objects.get(pk=int(buyer_id), is_buyer=True)  # Convert buyer_id to integer
        except ValueError:
            return Response({'error': 'Buyer ID must be an integer'}, status=status.HTTP_400_BAD_REQUEST)
        except User.DoesNotExist:
            return Response({'error': 'Buyer not found'}, status=status.HTTP_404_NOT_FOUND)

        buyer_location = (buyer.lat, buyer.long)
        vendors = User.objects.filter(is_vendor=True)
        
        nearby_vendors = [
            vendor for vendor in vendors
            if geodesic(buyer_location, (vendor.lat, vendor.long)).km <= 10
        ]

        nearby_vendor_ids = [vendor.id for vendor in nearby_vendors]
        nearby_vendor_products = Product.objects.filter(user_id__in=nearby_vendor_ids)
        serialized_products = ProductSer(nearby_vendor_products, many=True).data

        return Response(serialized_products, status=status.HTTP_200_OK)

class ResendOTPRequestViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorPasswordResetRequestSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')

        try:
            # Fetch the user by email
            user = User.objects.filter(email = email).first()

            # Generate OTP
            otp = generate_otp()
            user.otp = otp
            user.save()

            # Send OTP via Email
            body = f'Your OTP is: {otp}'

            data = {
                'subject': 'Email OTP for verification',
                'body': body,
                'to_email': email
            }

            send_email_to_client(data)

            return Response({'msg': 'OTP resend successfully '}, status=status.HTTP_200_OK)
        except ObjectDoesNotExist:
            return Response({'error': 'User with this email does not exist.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
class ChangePasswordViewSet(viewsets.ViewSet):
    # queryset = AdminUser.objects.all()
    serializer_class = ChangePasswordSer
    # pagination_class = CustomPagination
    # permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        # otp = request.data.pop('otp')
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data.get('email')
        old_password = serializer.validated_data.get('old_password')
        password = serializer.validated_data.get('password')
        confirm_password = serializer.validated_data.get('confirm_password')

        user = User.objects.filter(email = email).first()
        if not check_password(old_password,user.password):
            return Response({'msg':'The old password you entered is incorrect. Please try again.'},status=status.HTTP_400_BAD_REQUEST)
        else:
            if password!=confirm_password:
                return Response({'msg':'Password and ConfirmPassword should be same. Please try again.'},status=status.HTTP_400_BAD_REQUEST)
            else:
                user.set_password(password)
                user.save()
                return Response({'msg':f'Password Changed Successfully'}, status = status.HTTP_200_OK)
                      
class VendorProduct(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = VendorProfileSer
    # pagination_class = CustomPagination
    # authentication_classes = [CustomJWTAuthentication]

    def retrieve(self, request,pk=None):
        # vendor = request.user.id   

        # vendor_obj = User.objects.filter(id = pk , is_vendor = True).first()
        vendor_obj = get_object_or_404(User, id=pk, is_vendor=True)
        
        if vendor_obj == None:
            return Response({'error':'User not exist'},status=status.HTTP_404_NOT_FOUND)
        serializer = self.get_serializer(vendor_obj)
        products = Product.objects.filter(user=vendor_obj)
        product_serializer = ProductSer(products, many=True,context={'request':request})
        products_data = product_serializer.data


        return Response({'msg':'vendor profile fetched successfully','data':serializer.data,'products': product_serializer.data}, status = status.HTTP_200_OK)
    
   
    
