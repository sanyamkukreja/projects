from django.shortcuts import render
from .models import *
from rest_framework.response import Response
from rest_framework import viewsets
from django.shortcuts import render
from .models import Message

from rest_framework import status
from .serializers import *
# from suscription.custom_pagination import CustomPagination
# Create your views here.
class MessageViewSet(viewsets.ModelViewSet):
    queryset = Message.objects.all()
    serializer_class = MessageSerializer
    # pagination_class = CustomPagination

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)