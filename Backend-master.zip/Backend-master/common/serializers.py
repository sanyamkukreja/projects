from rest_framework import serializers
from .models import Message

class MessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Message
        fields = ['id', 'image']

    image = serializers.ImageField(max_length=None, allow_empty_file=False, use_url=True)