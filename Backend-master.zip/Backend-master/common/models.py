from django.db import models

# Create your models here.
class Message(models.Model):
    image=models.ImageField(upload_to='e360/images/')
    def get_image_url(self):
        if self.image:
            return self.image.url
        return ''