from django.apps import AppConfig


class SuscriptionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'suscription'
    
    def ready(self):
        import suscription.custom_auth_extension