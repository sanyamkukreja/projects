from django.shortcuts import render
from rest_framework.response import Response
# from .custom_pagination import CustomPagination
from rest_framework import viewsets
from .models import *
from .serializers import *
from rest_framework.exceptions import ValidationError
from rest_framework.pagination import PageNumberPagination
class PlanViewSet(viewsets.ModelViewSet):
    queryset = Plan.objects.all()
    serializer_class = PlanSerializer
    # pagination_class = CustomPagination

class SubscribeViewSet(viewsets.ModelViewSet):
   
    queryset = subscribe.objects.all()
    def get_serializer_class(self):
        if self.action == 'list' or self.action == 'retrieve':
            return SubscribeSerializer
        elif self.action == 'create':
            return SubscribeCreateSerializer
        return SubscribeUpdateSerializer 
    # pagination_class = CustomPagination
    def list(self, request):
        queryset = subscribe.objects.all().order_by('id')
        # Use the custom queryset method to get subscriptions
        user_id = request.query_params.get('user_id')
        if user_id:
            # Filter subscriptions by the provided user_id
            queryset =queryset.filter(user_id=user_id)
        for sub in queryset:
            sub.is_expired = sub.check_expiration()
            sub.save()

        # page = self.paginate_queryset(queryset)
        # if page is not None:
        #     serializer = self.get_serializer(page, many=True)
        #     return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)