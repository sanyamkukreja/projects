# middleware.py
from django.utils import timezone
from .models import subscribe

class UpdateSubscriptionStatusMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Update expiration status for all subscriptions
        subscriptions = subscribe.objects.all()
        for sub in subscriptions:
            # Update is_expired only if expiration_date is not None
            if sub.expiration_date is not None:
                sub.is_expired = sub.check_expiration()
                sub.save()
        
        response = self.get_response(request)
        return response
