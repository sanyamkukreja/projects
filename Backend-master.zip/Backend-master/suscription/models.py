from datetime import datetime
from django.db import models
from login_signup.models import User
from django.utils import timezone
from dateutil.relativedelta import relativedelta  # Use this for month calculations
from datetime import timedelta
# Create your models here.
class Plan(models.Model):
    name=models.CharField(max_length=20)
    limit=models.IntegerField(blank=True,null=True)
    price=models.FloatField(default=0.00,blank=True,null=True)
    price3=models.FloatField(default=0.00,blank=True,null=True)
    price6=models.FloatField(default=0.00,blank=True,null=True)
    price12=models.FloatField(default=0.00,blank=True,null=True)
    
    
    def __str__(self):
        return self.name
    
class subscribe(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'user_plan')
    plan = models.ForeignKey(Plan, on_delete = models.CASCADE, related_name = 'plans')
    duration =models.IntegerField(blank=True,null=True)
    created_at = models.DateTimeField(default=timezone.now)  # Add this field
    expiration_date = models.DateTimeField(blank=True, null=True)  
    is_expired = models.BooleanField(default=False)  # Add this field
    
    def __str__(self):
        return f"{self.plan.name}"
    
    def check_expiration(self):
        # Check if the current date is past the expiration date
        return timezone.now() > self.expiration_date if self.expiration_date else False

    def save(self, *args, **kwargs):
        if self.duration is not None:
            self.expiration_date = self.created_at + timedelta(days=self.duration)
        else:
            # Handle case where duration is not provided
            self.expiration_date = None
        super().save(*args, **kwargs)
