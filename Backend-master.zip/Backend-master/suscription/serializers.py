from rest_framework import serializers
from .models import Plan, subscribe
from login_signup.serializers import UserProfileSerializer 
from django.utils import timezone
class PlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plan
        fields = '__all__'

class SubscribeSerializer(serializers.ModelSerializer):
    user = UserProfileSerializer()
    plan = PlanSerializer()
    class Meta:
        model = subscribe
        fields = '__all__'
        
class SubscribeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = subscribe
        fields = '__all__'
        read_only_fields = ['created_at', 'expiration_date', 'is_expired']
    
        
    def validate(self, data):
        user = data.get('user')
        if subscribe.objects.filter(user=user).exists():
            raise serializers.ValidationError("This user already has a subscription.")
        
        return data
    
class SubscribeUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = subscribe
        fields = '__all__'
        read_only_fields = ['created_at', 'expiration_date', 'is_expired']
    def update(self, instance, validated_data):
        # Set is_expired to False during update
        instance.is_expired = False
# Update created_at with the current time
        instance.created_at = timezone.now()
        # Perform the update
        instance = super().update(instance, validated_data)
        
        # Save the instance
        instance.save()
        
        return instance