
#for clear pycache file
py manage.py clean_pyc 
git rm -r --cached db.sqlite3

