"""
URL configuration for vendor_listing project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
# from django.urls import path, include

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('api/login_signup/',include('login_signup.urls')),
#     path('api/product/',include('product.urls')),

# ]

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from Help_Support.views import *
from login_signup.views import *
from product.views import *
from suscription.views import *
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView
from rest_framework import permissions
from django.urls import re_path
from common.views import *
from login_signup.views import test_redis  # Import the view


router = routers.DefaultRouter()
...


###common###########
router.register(r'common/messages', MessageViewSet, basename='messages')

#help and support###########################3

router.register(r'Help_Support/FAQ-ASk',FAQViewSet, basename='FAQ-VIEW')
router.register(r'Help_Support/report-ASk',ReportViewSet, basename='Report-VIEW')
router.register(r'Help_Support/product_reports', ProductReportViewSet, basename='product-view')


#login_signup###################################
router.register(r'login_signup/admin_login', AdminLoginViewSet, basename='admin-login')
router.register(r'login_signup/admin-password-reset-request',AdminPasswordResetRequestViewSet, basename = 'admin-password-reset-request')
router.register(r'login_signup/admin-otp-verify', AdminPasswordResetViewSet, basename = 'admin-otp-verify')

router.register(r'login_signup/vendor-register',VendorRegisterViewSet, basename='vendor-register')
router.register(r'login_signup/vendor-otp-verify',VendorOTPVerifyViewSet, basename='vendor-otp-verify')
router.register(r'login_signup/vendor-login',VendorLoginViewSet, basename='vendor-login')
router.register(r'login_signup/vendor-password-reset-request',VendorPasswordResetRequestViewSet, basename = 'vendor-password-reset-request')
router.register(r'login_signup/vendor-otp-verify-password-reset', VendorPasswordResetOTPVerifyViewSet, basename = 'vendor-otp-verify-password-reset')
router.register(r'login_signup/vendor-password-reset', VendorPasswordResetViewSet, basename = 'vendor-password-reset')

router.register(r'login_signup/buyer-register',BuyerRegisterViewSet, basename='buyer-register')
router.register(r'login_signup/buyer-otp-verify',BuyerOTPVerifyViewSet, basename='buyer-otp-verify')
router.register(r'login_signup/buyer-login',BuyerLoginViewSet, basename='Buyer-login')
router.register(r'login_signup/buyer-password-reset-request', BuyerPasswordResetRequestViewSet, basename = 'buyer-password-reset-request')
router.register(r'login_signup/buyer-otp-verify-password-reset', BuyerPasswordResetOTPVerifyViewSet, basename = 'buyer-otp-verify-password-reset')
router.register(r'login_signup/buyer-password-reset', BuyerPasswordResetViewSet, basename = 'buyer-password-reset')

router.register(r'login_signup/vendor-profile', VendorProfile, basename = 'vendor-profile-view')
router.register(r'login_signup/buyer-profile', BuyerProfile, basename = 'buyer-profile-view')
router.register(r'login_signup/user-retrieve',UserRetrieveViewSet, basename = 'retrieve-all-user')
router.register(r'login_signup/vendorproduct',VendorProduct,basename='vendor-product')
# router for providing permissions
router.register(r'login_signup/vendor-user-permission',VendorUserPermissionViewSet, basename='vendor-user-permission')
router.register(r'login_signup/admin/groups',GroupCreateView,basename='create-group')
# Permissions List Router ############################3
router.register(r'login_signup/permission-list',PermissonsRetrieveViewSet, basename = 'permission-list')
router.register(r'login_signup/Admin-register',AdminRegisterviewset, basename = 'Admin-register')
router.register(r'login_signup/nearby-vendors',UserViewSet,basename='Nearby_vendor')
router.register(r'login_signup/ResendOtp',ResendOTPRequestViewSet,basename='resend-otp')
router.register(r'login_signup/ChangePassword',ChangePasswordViewSet,basename='change-password')

#products ###########################################
router.register(r'product/list-of-product-fields',ListProductViewSet, basename='list_of_product_fields')
router.register(r'product/category',CategoryMVS,basename = 'form_category')
router.register(r'product/website-category',WebsiteCategoryViewSet, basename='website-category')
router.register(r'product/sub_category',SubCategoryMVS, basename = 'form_sub_category')
router.register(r'product/dynamic-form-previous',FormMVS, basename = 'form_field')
router.register(r'product/dynamic-form',DynamicFormMVS, basename = 'dynamic_form')
router.register(r'product/product_form',ProductMVS, basename='product-form-for-filling')
router.register(r'product/review',ReviewViewSet,basename='review-product') 
router.register(r'product/help_full',HelpFullViewSet, basename='product-help-full')
router.register(r'product/fav_product',FavProductViewSet, basename='product-fav')
router.register(r'product/vendor-product-list',VendorProductListMVS, basename='vendor-product-list')  
router.register(r'product/offer-model',OfferModelViewSet, basename='offer-product-list')  
router.register(r'product/product_offers', ProductOfferViewSet, basename='product-offers')

# suscription
router.register(r'plans', PlanViewSet)
router.register(r'subscriptions', SubscribeViewSet)

urlpatterns = [
    path('test_redis/', test_redis, name='test_redis'),  # Add the URL pattern
    path('admin/', admin.site.urls),
    path('api/',include(router.urls)),
    path("schema/", SpectacularAPIView.as_view(), name="schema"),
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/schema/swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    path(
        "docs/",
        SpectacularSwaggerView.as_view(
            template_name="swagger-ui.html", url_name="schema"
        ),
        name="swagger-ui",
    ),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
