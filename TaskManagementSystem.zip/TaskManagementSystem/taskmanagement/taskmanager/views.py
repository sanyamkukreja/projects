from django.shortcuts import render
from rest_framework import viewsets,generics,permissions
from .models import Task,Author
from .serializers import TaskSerializer,AuthorSerializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.exceptions import NotFound
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
import secrets
from .custom_authentication import CustomJWTAuthentication
from .models import Author
from django.contrib.auth.hashers import check_password, make_password



def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }




# Create your views here.
class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    authentication_classes=[CustomJWTAuthentication]


    def perform_create(self, serializer):
        author_id = self.request.data.get('author')
        if not author_id:
            default_author = Author.objects.first()  # Fetch or create a default author
            if not default_author:
                raise ValueError("No default author available")
            serializer.save(author=default_author)
        else:
            serializer.save()
    
    
    
    @action(detail=False, methods=['delete'])
    def delete_all(self, request):
        deleted_count, _ = Task.objects.all().delete()
        if deleted_count == 0:
            return Response({"detail": "Task doesn't exist"}, status=status.HTTP_404_NOT_FOUND)
        return Response({"detail": f"All {deleted_count} tasks deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
    
    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            self.perform_destroy(instance)
            return Response({"detail": "Task deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
        except NotFound:
            return Response({"detail": "Task does not exist"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    
class AuthorViewSet(viewsets.ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer

    @action(detail=False, methods=['post'], url_path='login')
    def login(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        user_obj=Author.objects.filter(email=email).first()
        if user_obj == None:
            return Response({'msg':'user with this email id not exist'},status=status.HTTP_404_NOT_FOUND)
        

        if not check_password(password,user_obj.password):
            return Response({'msg':'Incorrect password'},status=status.HTTP_400_BAD_REQUEST)
        
        token = get_tokens_for_user(user_obj)
        

        return Response({'msg':'Login successful', 'token':token},status=status.HTTP_200_OK) 