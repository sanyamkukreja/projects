from rest_framework import serializers
from .models import Task, Author
from django.contrib.auth import get_user_model


class AuthorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Author
        fields = ['id','email', 'password', 'name', 'mobile', 'jwt_token']
        extra_kwargs = {
            'password': {'write_only': True},  # Password should not be readable
            'jwt_token': {'read_only': True},  # JWT token should not be modifiable by the user
        }

    def create(self, validated_data):
        user = Author.objects.create_user(
            email=validated_data['email'],
            password=validated_data['password'],
            name=validated_data.get('name', ''),
            mobile=validated_data.get('mobile', ''),
        )
        # Optionally, set jwt_token here if needed
        return user

class TaskSerializer(serializers.ModelSerializer):
    author = serializers.PrimaryKeyRelatedField(queryset=Author.objects.all(), required=False)


    class Meta:
        model = Task
        fields = ['id', 'title', 'description', 'completed', 'created_at', 'updated_at','author','image']
    
    def create(self, validated_data):
        author = validated_data.get('author', None)
        if author is None:
            default_author = Author.objects.first()  # Fetch or create a default author
            if not default_author:
                raise ValueError("No default author available")
            validated_data['author'] = default_author
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        author = validated_data.get('author', None)
        if author is None:
            validated_data['author'] = instance.author
        return super().update(instance, validated_data)
          